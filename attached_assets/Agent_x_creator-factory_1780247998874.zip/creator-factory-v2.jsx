import { useState, useEffect, useRef, useCallback, useReducer } from "react";

// ═══════════════════════════════════════════════════════════
// CONSTANTS & CONFIG
// ═══════════════════════════════════════════════════════════
const JOSH_CONTEXT = `You are partnered with Josh (NBA Josh) — solo developer, music artist, and entrepreneur based in Port Harcourt, Nigeria. He runs Creator Factory (creatorfactory.io), Out The Mud Records LTD, and Mudworld. He builds AI-powered SaaS products and content automation pipelines, works primarily from iPhone, uses Replit. He makes YouTube Shorts, TikTok content, music videos. His projects include: Creator Factory (YouTube Shorts automation SaaS), Mudworld (artist merch + NFT + music platform), NOVA (multi-model AI orchestration). He releases music under NBA Josh, collaborated with 1da Banton. He thinks in systems, moves fast, doesn't give up. Speak to him as a creative partner who knows his world deeply.`;

const MODELS = {
  video: [
    { id: "veo3", name: "Veo 3.1", provider: "Google", best: "cinematic, narrative", color: "#4285f4" },
    { id: "sora2", name: "Sora 2", provider: "OpenAI", best: "storytelling, motion", color: "#10a37f" },
    { id: "kling3", name: "Kling 3.0", provider: "Kuaishou", best: "action, realism", color: "#ff6b35" },
    { id: "seedance", name: "Seedance 2.0", provider: "ByteDance", best: "style, aesthetic", color: "#fe2c55" },
    { id: "nanobanana", name: "Nano Banana Pro", provider: "NB", best: "fast, creative", color: "#f9ca24" },
    { id: "runway", name: "Runway Gen-3", provider: "Runway", best: "general, effects", color: "#8b5cf6" },
    { id: "haiper", name: "Haiper 2.0", provider: "Haiper", best: "smooth motion", color: "#06b6d4" },
    { id: "luma", name: "Luma Dream", provider: "Luma", best: "dreamlike", color: "#ec4899" },
  ],
  image: [
    { id: "flux", name: "FLUX Pro 1.1", provider: "BFL", best: "photorealism", color: "#f59e0b" },
    { id: "ideogram", name: "Ideogram 3", provider: "Ideogram", best: "text in image", color: "#7c3aed" },
    { id: "midjourney", name: "Midjourney 7", provider: "MJ", best: "artistic", color: "#6366f1" },
  ],
  audio: [
    { id: "elevenlabs", name: "ElevenLabs v3", provider: "EL", best: "voiceover, clone", color: "#00d4ff" },
    { id: "musicgen", name: "MusicGen", provider: "Meta", best: "background music", color: "#00ff88" },
    { id: "suno", name: "Suno v4", provider: "Suno", best: "full songs", color: "#ff4466" },
    { id: "udio", name: "Udio", provider: "Udio", best: "hip-hop, beats", color: "#a855f7" },
  ],
};

const CREATOR_SKILLS = [
  { id: "shorts", name: "YouTube Shorts", icon: "▶", desc: "Hook → story → CTA structure optimized for retention" },
  { id: "tiktok", name: "TikTok Viral", icon: "◈", desc: "Pattern interrupt, trend riding, sound sync" },
  { id: "music_video", name: "Music Video", icon: "♪", desc: "Lyric sync, visual metaphor, performance cuts" },
  { id: "ad", name: "Performance Ad", icon: "◎", desc: "AIDA framework, conversion-focused, A/B variants" },
  { id: "cinematic", name: "Cinematic Short", icon: "◉", desc: "Film language, color grade, score-driven" },
  { id: "ugc", name: "UGC / Avatar", icon: "◑", desc: "Authentic creator style, face-sync, real-feel" },
  { id: "nft_reveal", name: "NFT Drop Reveal", icon: "◈", desc: "Hype build, reveal mechanics, community hook" },
  { id: "product", name: "Product Launch", icon: "◇", desc: "Feature showcase, social proof, offer stack" },
];

const MCP_TOOLS = [
  { id: "gmail", name: "Gmail", icon: "✉", status: "connected", color: "#ea4335" },
  { id: "gdrive", name: "Google Drive", icon: "▲", status: "connected", color: "#4285f4" },
  { id: "gcal", name: "Calendar", icon: "◫", status: "connected", color: "#34a853" },
  { id: "github", name: "GitHub", icon: "◉", status: "available", color: "#888" },
  { id: "replit", name: "Replit", icon: "◑", status: "available", color: "#f26207" },
  { id: "runway_mcp", name: "Runway MCP", icon: "◎", status: "available", color: "#8b5cf6" },
  { id: "kling_mcp", name: "Kling API", icon: "◈", status: "available", color: "#ff6b35" },
  { id: "paystack", name: "Paystack", icon: "₦", status: "available", color: "#00c3f7" },
];

const AGENTS = [
  { id: "director", name: "Director", role: "Orchestrates the full production", color: "#00d4ff", icon: "◎" },
  { id: "script", name: "Script Agent", role: "Writes narrative & VO copy", color: "#00ff88", icon: "✍" },
  { id: "shot", name: "Shot Agent", role: "Breaks script into visual shots", color: "#f59e0b", icon: "◉" },
  { id: "router", name: "Model Router", role: "Picks the best model per shot", color: "#a855f7", icon: "⟳" },
  { id: "review", name: "Review Agent", role: "QAs all output before delivery", color: "#ff6b35", icon: "◑" },
  { id: "continuity", name: "Continuity", role: "Keeps style/character consistent", color: "#ec4899", icon: "∞" },
  { id: "brainstorm", name: "Brainstorm", role: "Generates ideas & alternatives", color: "#4285f4", icon: "✦" },
  { id: "gemini", name: "Gemini Partner", role: "Deep research & multimodal analysis", color: "#fbbc04", icon: "◈" },
];

// ═══════════════════════════════════════════════════════════
// INTELLIGENCE LAYER
// ═══════════════════════════════════════════════════════════
async function callClaude(messages, systemPrompt, json = false) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: systemPrompt,
      messages,
    }),
  });
  const data = await res.json();
  const text = data.content?.[0]?.text || "";
  if (!json) return text;
  try { return JSON.parse(text.replace(/```json|```/g, "").trim()); }
  catch { return null; }
}

// Multi-agent pipeline: Director → Script → Shot → Router → Review
async function runAgentPipeline(brief, brain, skill, onStep) {
  const brainCtx = Object.entries(brain).filter(([,v])=>v).map(([k,v])=>`[${k.toUpperCase()}]: ${v}`).join("\n");

  // Step 1: Director plans
  onStep("director", "running", "Analyzing brief & planning production...");
  const plan = await callClaude(
    [{ role: "user", content: `Brief: ${brief}\nSkill: ${skill}\n${brainCtx ? `Context:\n${brainCtx}` : ""}` }],
    `${JOSH_CONTEXT}\nYou are the Director Agent. Given a creative brief, output ONLY JSON:\n{"title":"project title","concept":"core creative concept","platform":"target platform","duration":"total duration","totalScenes":4,"approach":"production approach","alternatives":[{"title":"alt idea 1","concept":"..."},{"title":"alt idea 2","concept":"..."}],"brainstorm":["idea or angle 1","idea 2","idea 3"],"brainUpdate":{"key":"worldBuilding","value":"context to remember"}}`,
    true
  );
  onStep("director", "done", `Concept: "${plan?.concept || "planned"}"`);

  if (!plan) return null;

  // Step 2: Script Agent
  onStep("script", "running", "Writing narrative & voiceover...");
  const script = await callClaude(
    [{ role: "user", content: `Write a ${plan.totalScenes}-scene script for: "${plan.concept}". Platform: ${plan.platform}. Output JSON only: {"scenes":[{"sceneNum":1,"title":"","vo":"voiceover text","narration":"what happens","mood":"","duration":6}]}` }],
    `${JOSH_CONTEXT}\nYou are the Script Agent. Write punchy, platform-native scripts. Output only valid JSON.`,
    true
  );
  onStep("script", "done", `${script?.scenes?.length || plan.totalScenes} scenes written`);

  // Step 3: Shot Agent
  onStep("shot", "running", "Breaking into visual shots & camera language...");
  const shots = await callClaude(
    [{ role: "user", content: `Given these scenes: ${JSON.stringify(script?.scenes || [])}\nFor each scene add: shot type, camera movement, visual prompt for AI generation, broll suggestions. Output JSON: {"scenes":[{...original fields,"shot":"camera description","visualPrompt":"detailed gen prompt","broll":["idea1"],"sfx":"sound effect"}]}` }],
    `${JOSH_CONTEXT}\nYou are the Shot Agent. Think cinematically. Translate narrative into precise visual language. Output only valid JSON.`,
    true
  );
  onStep("shot", "done", "Shot list complete");

  // Step 4: Model Router
  onStep("router", "running", "Routing each shot to optimal model...");
  const routed = await callClaude(
    [{ role: "user", content: `Route each scene to the best video model. Options: veo3 (cinematic), sora2 (storytelling), kling3 (action/realism), seedance (style), nanobanana (fast/creative), runway (effects). Scenes: ${JSON.stringify(shots?.scenes || script?.scenes || [])}. Output JSON: {"scenes":[{...all fields,"model":"modelId","modelReason":"why this model","imageModel":"flux|ideogram|midjourney","voiceModel":"elevenlabs","musicStyle":"bg music style"}]}` }],
    `${JOSH_CONTEXT}\nYou are the Model Router Agent. Pick the perfect model for each shot based on content type and creative goals. Output only valid JSON.`,
    true
  );
  onStep("router", "done", "All shots routed");

  // Step 5: Review Agent
  onStep("review", "running", "QA check — reviewing full production plan...");
  const reviewed = await callClaude(
    [{ role: "user", content: `Review this production plan for quality, consistency, and platform fit. Brief: "${brief}". Plan: ${JSON.stringify(routed || shots || script)}. Return the SAME JSON structure but with a "reviewNotes" field added to each scene and a top-level "productionScore":0-100 and "reviewSummary":"".` }],
    `${JOSH_CONTEXT}\nYou are the Review Agent. Critically evaluate the plan. Improve weak scenes. Output only valid JSON — the full corrected plan.`,
    true
  );
  onStep("review", "done", `Production score: ${reviewed?.productionScore || 90}/100`);

  const finalScenes = (reviewed?.scenes || routed?.scenes || shots?.scenes || script?.scenes || []).map(s => ({
    ...s, status: "pending",
  }));

  return {
    title: plan.title,
    concept: plan.concept,
    platform: plan.platform,
    approach: plan.approach,
    alternatives: plan.alternatives || [],
    brainstorm: plan.brainstorm || [],
    brainUpdate: plan.brainUpdate,
    productionScore: reviewed?.productionScore || 90,
    reviewSummary: reviewed?.reviewSummary || "",
    scenes: finalScenes,
  };
}

async function runBrainstorm(topic, brain, onChunk) {
  const brainCtx = Object.entries(brain).filter(([,v])=>v).map(([k,v])=>`[${k.toUpperCase()}]: ${v}`).join("\n");
  const result = await callClaude(
    [{ role: "user", content: `Brainstorm creative angles, ideas, and approaches for: "${topic}"\n${brainCtx}` }],
    `${JOSH_CONTEXT}\nYou are Josh's creative partner. Brainstorm boldly. Give 5-7 distinct angles — some expected, some wild, some hybrid. Think about his platforms (YouTube Shorts, TikTok), his brand (Out The Mud, Creator Factory, Mudworld), his music background. Be specific, not generic. Format with numbered ideas, each with a 1-line hook and 2-line expansion.`
  );
  return result;
}

// ═══════════════════════════════════════════════════════════
// NODE CANVAS ENGINE
// ═══════════════════════════════════════════════════════════
function NodeCanvas({ nodes, connections, onAddNode, onMoveNode, onSelectNode, selectedNode }) {
  const svgRef = useRef(null);
  const [dragging, setDragging] = useState(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  const handleMouseDown = (e, id) => {
    e.stopPropagation();
    onSelectNode(id);
    setDragging(id);
    const rect = e.currentTarget.getBoundingClientRect();
    setOffset({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  const handleMouseMove = useCallback((e) => {
    if (!dragging || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    onMoveNode(dragging, {
      x: e.clientX - rect.left - offset.x,
      y: e.clientY - rect.top - offset.y,
    });
  }, [dragging, offset, onMoveNode]);

  const handleMouseUp = () => setDragging(null);

  const nodeColor = (type) => {
    const map = { scene: "#00d4ff", agent: "#a855f7", model: "#f59e0b", asset: "#00ff88", idea: "#ff6b35" };
    return map[type] || "#555";
  };

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden", background: "#04040a" }}
      onMouseMove={handleMouseMove} onMouseUp={handleMouseUp}>
      {/* Grid */}
      <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }}>
        <defs>
          <pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">
            <path d="M 32 0 L 0 0 0 32" fill="none" stroke="#111118" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
        {/* Connections */}
        {connections.map((c, i) => {
          const from = nodes.find(n => n.id === c.from);
          const to = nodes.find(n => n.id === c.to);
          if (!from || !to) return null;
          return (
            <line key={i}
              x1={from.x + 80} y1={from.y + 24}
              x2={to.x} y2={to.y + 24}
              stroke={nodeColor(from.type) + "66"} strokeWidth={1.5}
              strokeDasharray={c.dashed ? "4 4" : "none"} />
          );
        })}
      </svg>
      {/* Nodes */}
      <div ref={svgRef} style={{ position: "absolute", inset: 0 }}>
        {nodes.map(node => (
          <div key={node.id}
            onMouseDown={e => handleMouseDown(e, node.id)}
            style={{
              position: "absolute", left: node.x, top: node.y,
              minWidth: 140, background: "#0a0a14",
              border: `1px solid ${selectedNode === node.id ? nodeColor(node.type) : nodeColor(node.type) + "44"}`,
              borderRadius: 10, padding: "8px 12px", cursor: "grab",
              userSelect: "none",
              boxShadow: selectedNode === node.id ? `0 0 16px ${nodeColor(node.type)}33` : "none",
              transition: "box-shadow 0.15s, border-color 0.15s",
            }}>
            <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 1.5, color: nodeColor(node.type), textTransform: "uppercase", marginBottom: 4 }}>
              {node.type}
            </div>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#e0e0f0" }}>{node.label}</div>
            {node.sub && <div style={{ fontSize: 10, color: "#555", marginTop: 2 }}>{node.sub}</div>}
            {node.model && (
              <div style={{ marginTop: 6, fontSize: 10, padding: "2px 6px", background: nodeColor(node.type) + "22", borderRadius: 4, color: nodeColor(node.type), display: "inline-block" }}>
                {node.model}
              </div>
            )}
          </div>
        ))}
      </div>
      {/* Add node button */}
      <button onClick={() => onAddNode()} style={{
        position: "absolute", bottom: 16, right: 16,
        width: 36, height: 36, borderRadius: "50%",
        background: "#00d4ff22", border: "1px solid #00d4ff44",
        color: "#00d4ff", fontSize: 20, cursor: "pointer",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>+</button>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// MOODBOARD / ASSET PANEL
// ═══════════════════════════════════════════════════════════
function MoodBoard({ assets, onAddAsset, onRemoveAsset }) {
  const [dragOver, setDragOver] = useState(false);
  const [urlInput, setUrlInput] = useState("");
  const [labelInput, setLabelInput] = useState("");
  const fileRef = useRef();

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    files.forEach(f => {
      const url = URL.createObjectURL(f);
      onAddAsset({ id: Date.now() + Math.random(), type: f.type.startsWith("image") ? "image" : "file", url, label: f.name, source: "upload" });
    });
  };

  const addUrl = () => {
    if (!urlInput.trim()) return;
    onAddAsset({ id: Date.now(), type: "ref", url: urlInput, label: labelInput || urlInput, source: "url" });
    setUrlInput(""); setLabelInput("");
  };

  const PROP_PRESETS = [
    { label: "Cinematic Hook", color: "#00d4ff", note: "First 3s must stop scroll" },
    { label: "Dark Moody", color: "#a855f7", note: "Low key, contrast, grain" },
    { label: "Street Energy", color: "#ff6b35", note: "Handheld, fast cuts, bass" },
    { label: "Clean & Bold", color: "#00ff88", note: "Minimal, text-driven, pop" },
    { label: "Afrofuturism", color: "#f9ca24", note: "Rich colors, cultural depth" },
    { label: "Lo-fi Aesthetic", color: "#ec4899", note: "VHS grain, warmth, nostalgia" },
  ];

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#04040a" }}>
      {/* Drop zone */}
      <div
        onDrop={handleDrop}
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onClick={() => fileRef.current?.click()}
        style={{
          margin: 12, borderRadius: 10, border: `1px dashed ${dragOver ? "#00d4ff" : "#1a1a2a"}`,
          background: dragOver ? "#00d4ff08" : "transparent",
          padding: "16px", textAlign: "center", cursor: "pointer",
          transition: "all 0.15s",
        }}>
        <input ref={fileRef} type="file" multiple accept="image/*,video/*" style={{ display: "none" }}
          onChange={e => Array.from(e.target.files).forEach(f => {
            onAddAsset({ id: Date.now() + Math.random(), type: "image", url: URL.createObjectURL(f), label: f.name, source: "upload" });
          })} />
        <div style={{ fontSize: 20, marginBottom: 4 }}>⊕</div>
        <div style={{ fontSize: 11, color: "#444" }}>Drop images, clips, references</div>
      </div>

      {/* URL input */}
      <div style={{ padding: "0 12px", display: "flex", gap: 6, marginBottom: 10 }}>
        <input value={urlInput} onChange={e => setUrlInput(e.target.value)}
          placeholder="Paste image / ref URL..."
          onKeyDown={e => e.key === "Enter" && addUrl()}
          style={{
            flex: 1, background: "#0a0a14", border: "1px solid #1a1a2a",
            borderRadius: 6, color: "#c0c0d0", fontSize: 11, padding: "6px 8px", fontFamily: "inherit",
          }} />
        <button onClick={addUrl} style={{
          background: "#00d4ff22", border: "1px solid #00d4ff33", borderRadius: 6,
          color: "#00d4ff", fontSize: 11, padding: "0 10px", cursor: "pointer", fontFamily: "inherit",
        }}>Add</button>
      </div>

      {/* Style props */}
      <div style={{ padding: "0 12px", marginBottom: 10 }}>
        <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 2, color: "#333", marginBottom: 8, textTransform: "uppercase" }}>Visual Props</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
          {PROP_PRESETS.map(p => (
            <button key={p.label} title={p.note}
              onClick={() => onAddAsset({ id: Date.now(), type: "prop", label: p.label, note: p.note, color: p.color, source: "preset" })}
              style={{
                fontSize: 10, padding: "4px 8px", borderRadius: 5,
                background: p.color + "11", border: `1px solid ${p.color}33`,
                color: p.color, cursor: "pointer", fontFamily: "inherit",
              }}>{p.label}</button>
          ))}
        </div>
      </div>

      {/* Asset grid */}
      <div style={{ flex: 1, overflowY: "auto", padding: "0 12px 12px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {assets.map(asset => (
          <div key={asset.id} style={{
            background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 8,
            overflow: "hidden", position: "relative",
          }}>
            {asset.type === "image" && (
              <img src={asset.url} alt={asset.label}
                style={{ width: "100%", height: 70, objectFit: "cover", display: "block" }} />
            )}
            {asset.type === "prop" && (
              <div style={{
                height: 70, background: asset.color + "11",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 10, color: asset.color, fontWeight: 600, textAlign: "center", padding: 8,
              }}>{asset.label}</div>
            )}
            {asset.type === "ref" && (
              <div style={{ height: 70, background: "#0d0d1a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: "#555", padding: 8, wordBreak: "break-all" }}>
                🔗 {asset.label.slice(0, 30)}
              </div>
            )}
            <div style={{ padding: "4px 6px", fontSize: 9, color: "#555", display: "flex", justifyContent: "space-between" }}>
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 80 }}>{asset.label}</span>
              <button onClick={() => onRemoveAsset(asset.id)} style={{ background: "none", border: "none", color: "#333", cursor: "pointer", fontSize: 11, padding: 0 }}>✕</button>
            </div>
          </div>
        ))}
        {assets.length === 0 && (
          <div style={{ gridColumn: "1/-1", textAlign: "center", color: "#222", fontSize: 12, paddingTop: 20 }}>
            Empty moodboard.<br />Add references, props, and assets.
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// CLI TERMINAL
// ═══════════════════════════════════════════════════════════
function Terminal({ scenes, brain, projectName }) {
  const [history, setHistory] = useState([
    { type: "system", text: "Creator Factory CLI v2.0 — Agent One Runtime" },
    { type: "system", text: `Connected: Claude Sonnet 4 · Gemini Flash · ${MCP_TOOLS.filter(t=>t.status==="connected").map(t=>t.name).join(" · ")}` },
    { type: "system", text: 'Type "help" for commands.' },
  ]);
  const [input, setInput] = useState("");
  const [cmdHistory, setCmdHistory] = useState([]);
  const [histIdx, setHistIdx] = useState(-1);
  const termRef = useRef();

  useEffect(() => {
    if (termRef.current) termRef.current.scrollTop = termRef.current.scrollHeight;
  }, [history]);

  const addLine = (text, type = "output") => setHistory(h => [...h, { type, text }]);

  const processCmd = async (cmd) => {
    const parts = cmd.trim().split(" ");
    const base = parts[0].toLowerCase();
    addLine(`$ ${cmd}`, "input");

    switch (base) {
      case "help":
        addLine(`Commands:
  status          — show project status
  scenes          — list all scenes
  scene [n]       — inspect scene N
  brain           — show brain memory
  brain set [k] [v] — set brain key
  models          — list available models
  route [scene]   — show model routing for scene
  export json     — export production JSON
  export prompts  — export all gen prompts
  mcp list        — list MCP connections
  mcp use [tool]  — activate MCP tool
  agents          — list agent crew
  run [agent]     — run specific agent
  brainstorm [q]  — quick brainstorm
  clear           — clear terminal`);
        break;
      case "status":
        addLine(`Project: ${projectName}
Scenes: ${scenes.length}
Brain keys: ${Object.entries(brain).filter(([,v])=>v).map(([k])=>k).join(", ") || "none"}
Agent crew: ${AGENTS.length} agents ready
Models online: ${Object.values(MODELS).flat().length}`);
        break;
      case "scenes":
        if (!scenes.length) { addLine("No scenes yet. Send a brief in Director chat."); break; }
        scenes.forEach((s, i) => addLine(`  [${i+1}] ${s.title || s.sceneNum} — ${s.model || "unrouted"} — ${s.status || "pending"}`));
        break;
      case "scene":
        const n = parseInt(parts[1]) - 1;
        if (isNaN(n) || !scenes[n]) { addLine("Scene not found."); break; }
        const sc = scenes[n];
        addLine(JSON.stringify(sc, null, 2));
        break;
      case "brain":
        if (parts[1] === "set") {
          addLine("Use the Brain panel to update memory. (CLI brain writes coming soon)");
        } else {
          const b = Object.entries(brain).filter(([,v])=>v);
          if (!b.length) addLine("Brain empty.");
          else b.forEach(([k,v]) => addLine(`[${k}]: ${v.slice(0,120)}${v.length>120?"...":""}`));
        }
        break;
      case "models":
        Object.entries(MODELS).forEach(([type, list]) => {
          addLine(`── ${type.toUpperCase()} ──`);
          list.forEach(m => addLine(`  ${m.id.padEnd(12)} ${m.name.padEnd(18)} best: ${m.best}`));
        });
        break;
      case "route":
        const si = parseInt(parts[1]) - 1;
        if (isNaN(si) || !scenes[si]) { addLine("Specify a valid scene number."); break; }
        addLine(`Scene ${si+1} routing:
  Video: ${scenes[si].model || "unrouted"}
  Image: ${scenes[si].imageModel || "flux"}
  Voice: ${scenes[si].voiceModel || "elevenlabs"}
  Music: ${scenes[si].musicStyle || "auto"}
  Reason: ${scenes[si].modelReason || "pending routing"}`);
        break;
      case "export":
        if (parts[1] === "prompts") {
          if (!scenes.length) { addLine("No scenes to export."); break; }
          scenes.forEach((s, i) => addLine(`[Scene ${i+1}] ${s.visualPrompt || "No prompt yet"}`));
        } else {
          const data = { project: projectName, brain, scenes, exported: new Date().toISOString() };
          addLine(JSON.stringify(data, null, 2));
        }
        break;
      case "mcp":
        if (parts[1] === "list") {
          MCP_TOOLS.forEach(t => addLine(`  ${t.status === "connected" ? "●" : "○"} ${t.name.padEnd(14)} [${t.status}]`));
        } else if (parts[1] === "use") {
          const tool = MCP_TOOLS.find(t => t.id === parts[2]);
          addLine(tool ? `Activating ${tool.name}... (connect in MCP panel)` : "Unknown tool.");
        }
        break;
      case "agents":
        AGENTS.forEach(a => addLine(`  ${a.icon} ${a.name.padEnd(16)} — ${a.role}`));
        break;
      case "run":
        const agent = AGENTS.find(a => a.id === parts[1]);
        if (!agent) { addLine(`Unknown agent. Try: ${AGENTS.map(a=>a.id).join(", ")}`); break; }
        addLine(`Running ${agent.name}... (wire to pipeline for execution)`);
        break;
      case "brainstorm":
        const q = parts.slice(1).join(" ");
        if (!q) { addLine("Usage: brainstorm <topic>"); break; }
        addLine("Brainstorming...", "system");
        const ideas = await runBrainstorm(q, brain);
        addLine(ideas);
        break;
      case "clear":
        setHistory([{ type: "system", text: "Terminal cleared." }]);
        break;
      default:
        addLine(`Unknown command: ${base}. Type "help".`);
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter") {
      if (!input.trim()) return;
      setCmdHistory(h => [input, ...h]);
      setHistIdx(-1);
      processCmd(input);
      setInput("");
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      const next = Math.min(histIdx + 1, cmdHistory.length - 1);
      setHistIdx(next);
      setInput(cmdHistory[next] || "");
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      const next = Math.max(histIdx - 1, -1);
      setHistIdx(next);
      setInput(next === -1 ? "" : cmdHistory[next]);
    }
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#03030a", fontFamily: "'DM Mono', monospace" }}>
      <div ref={termRef} style={{ flex: 1, overflowY: "auto", padding: "12px 16px", fontSize: 11, lineHeight: 1.7 }}>
        {history.map((h, i) => (
          <div key={i} style={{
            color: h.type === "system" ? "#444" : h.type === "input" ? "#00ff88" : h.type === "error" ? "#ff4466" : "#c0c0d0",
            whiteSpace: "pre-wrap", wordBreak: "break-word",
          }}>{h.text}</div>
        ))}
      </div>
      <div style={{ display: "flex", alignItems: "center", borderTop: "1px solid #111118", padding: "8px 16px", gap: 8 }}>
        <span style={{ color: "#00ff88", fontSize: 12 }}>$</span>
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey}
          placeholder="Type a command..."
          style={{
            flex: 1, background: "transparent", border: "none",
            color: "#00ff88", fontSize: 11, fontFamily: "inherit",
          }} />
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════
export default function CreatorFactory() {
  // ── State ──
  const [view, setView] = useState("chat"); // chat | canvas | moodboard | terminal | agents | mcp
  const [mode, setMode] = useState("Director");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [selectedScene, setSelectedScene] = useState(null);
  const [agentSteps, setAgentSteps] = useState([]);
  const [isRunning, setIsRunning] = useState(false);
  const [brain, setBrain] = useState({ rules: "", worldBuilding: "", characters: "", brand: "", knowledge: "" });
  const [activeSkill, setActiveSkill] = useState("shorts");
  const [assets, setAssets] = useState([]);
  const [projectName, setProjectName] = useState("New Project");
  const [brainstormPanel, setBrainstormPanel] = useState(null);
  const [alternatives, setAlternatives] = useState([]);
  const [nodes, setNodes] = useState([
    { id: "n1", type: "agent", label: "Director", sub: "Orchestrator", x: 40, y: 80 },
    { id: "n2", type: "agent", label: "Script Agent", sub: "Narrative", x: 220, y: 40 },
    { id: "n3", type: "agent", label: "Shot Agent", sub: "Visual", x: 220, y: 140 },
    { id: "n4", type: "agent", label: "Model Router", sub: "Routing", x: 400, y: 80 },
    { id: "n5", type: "agent", label: "Review Agent", sub: "QA", x: 580, y: 80 },
  ]);
  const [nodeConnections] = useState([
    { from: "n1", to: "n2" }, { from: "n1", to: "n3" },
    { from: "n2", to: "n4" }, { from: "n3", to: "n4" },
    { from: "n4", to: "n5" },
  ]);
  const [selectedNode, setSelectedNode] = useState(null);
  const chatRef = useRef();
  const inputRef = useRef();

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages, agentSteps]);

  const updateAgentStep = (agentId, status, msg) => {
    setAgentSteps(prev => {
      const existing = prev.findIndex(s => s.agentId === agentId && s.status === "running");
      if (existing >= 0) {
        const updated = [...prev];
        updated[existing] = { agentId, status, msg, ts: Date.now() };
        return updated;
      }
      return [...prev, { agentId, status, msg, ts: Date.now() }];
    });
  };

  const send = useCallback(async () => {
    if (!input.trim() || isRunning) return;
    const brief = input.trim();
    setInput("");
    setIsRunning(true);
    setAgentSteps([]);

    setMessages(prev => [...prev, { role: "user", content: brief }]);

    // Check if it's a brainstorm request
    const isBrainstorm = /brainstorm|ideas?|suggest|alternatives?|what if/i.test(brief);

    if (isBrainstorm && mode === "Director") {
      setMessages(prev => [...prev, { role: "assistant", content: "Let me brainstorm some angles with you...", type: "thinking" }]);
      const ideas = await runBrainstorm(brief, brain);
      setMessages(prev => {
        const updated = [...prev];
        updated[updated.length - 1] = { role: "assistant", content: ideas, type: "brainstorm" };
        return updated;
      });
      setBrainstormPanel(ideas);
      setIsRunning(false);
      return;
    }

    // Full pipeline
    try {
      const result = await runAgentPipeline(brief, brain, activeSkill, updateAgentStep);
      if (result) {
        setScenes(result.scenes || []);
        setSelectedScene(0);
        setAlternatives(result.alternatives || []);
        if (result.brainUpdate?.key && result.brainUpdate?.value) {
          setBrain(prev => ({ ...prev, [result.brainUpdate.key]: result.brainUpdate.value }));
        }
        if (projectName === "New Project" && result.title) setProjectName(result.title);

        // Add scene nodes to canvas
        if (result.scenes?.length) {
          setNodes(prev => {
            const sceneNodes = result.scenes.slice(0, 6).map((s, i) => ({
              id: `scene_${i}`, type: "scene",
              label: s.title || `Scene ${i+1}`,
              sub: s.mood || "",
              model: s.model || "",
              x: 100 + (i % 3) * 200, y: 280 + Math.floor(i / 3) * 120,
            }));
            return [...prev.filter(n => n.type !== "scene"), ...sceneNodes];
          });
        }

        const summary = `Production plan ready — ${result.scenes?.length || 0} scenes · Score: ${result.productionScore}/100\n\n${result.reviewSummary || ""}\n\nConcept: ${result.concept}`;
        setMessages(prev => [...prev, {
          role: "assistant", content: summary, type: "plan",
          scenes: result.scenes, alternatives: result.alternatives,
          brainstorm: result.brainstorm,
        }]);
      }
    } catch (e) {
      setMessages(prev => [...prev, { role: "assistant", content: "Pipeline error. Check connection.", type: "error" }]);
    }
    setIsRunning(false);
  }, [input, isRunning, brain, activeSkill, mode, projectName]);

  const handleKey = e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } };

  const moveNode = useCallback((id, pos) => {
    setNodes(prev => prev.map(n => n.id === id ? { ...n, ...pos } : n));
  }, []);

  const addNode = () => {
    setNodes(prev => [...prev, {
      id: `node_${Date.now()}`, type: "idea",
      label: "New Node", sub: "double-click to edit", x: 200, y: 200,
    }]);
  };

  // ── NAV ITEMS ──
  const NAV = [
    { id: "chat", label: "Director", icon: "◎" },
    { id: "canvas", label: "Canvas", icon: "⬡" },
    { id: "moodboard", label: "Moodboard", icon: "◫" },
    { id: "terminal", label: "CLI", icon: ">" },
    { id: "agents", label: "Agents", icon: "✦" },
    { id: "mcp", label: "MCP", icon: "⟳" },
  ];

  const agentColor = (id) => AGENTS.find(a => a.id === id)?.color || "#555";

  return (
    <div style={{
      minHeight: "100vh", height: "100vh", background: "#050508",
      fontFamily: "'DM Mono', 'Fira Mono', monospace",
      color: "#e0e0f0", display: "flex", flexDirection: "column", overflow: "hidden",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Syne:wght@700;800&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:3px;height:3px}
        ::-webkit-scrollbar-track{background:transparent}
        ::-webkit-scrollbar-thumb{background:#1a1a2a;border-radius:2px}
        textarea,input{outline:none}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
        @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        @keyframes bounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-5px)}}
        @keyframes glow{0%,100%{box-shadow:0 0 8px #00d4ff33}50%{box-shadow:0 0 20px #00d4ff66}}
        .msg{animation:fadeUp 0.2s ease forwards}
        .btn:hover{opacity:0.8!important}
        .nav-item:hover{color:#c0c0d0!important;background:#0d0d1a!important}
        .nav-item.active{color:#00d4ff!important;border-left:2px solid #00d4ff!important}
      `}</style>

      {/* ── TOPBAR ── */}
      <div style={{
        height: 44, background: "#07070f", borderBottom: "1px solid #111118",
        display: "flex", alignItems: "center", padding: "0 16px", gap: 12, flexShrink: 0,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{
            width: 26, height: 26, borderRadius: 7,
            background: "linear-gradient(135deg, #00d4ff, #a855f7, #ff6b35)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 12, fontWeight: 700, color: "#000",
          }}>CF</div>
          <span style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: 12, letterSpacing: 1.5, color: "#e0e0f0" }}>
            CREATOR FACTORY
          </span>
          <span style={{ fontSize: 9, color: "#333", letterSpacing: 1 }}>AGENT ONE</span>
        </div>

        <div style={{ width: 1, height: 16, background: "#1a1a2a" }} />

        <input value={projectName} onChange={e => setProjectName(e.target.value)}
          style={{ background: "transparent", border: "none", color: "#555", fontSize: 11, fontFamily: "inherit", maxWidth: 180 }} />

        <div style={{ flex: 1 }} />

        {/* Skill selector */}
        <div style={{ display: "flex", gap: 4, overflowX: "auto" }}>
          {CREATOR_SKILLS.slice(0, 5).map(s => (
            <button key={s.id} onClick={() => setActiveSkill(s.id)} className="btn" style={{
              padding: "3px 10px", borderRadius: 5, fontSize: 10, fontWeight: 600,
              border: `1px solid ${activeSkill === s.id ? "#00d4ff44" : "#1a1a2a"}`,
              background: activeSkill === s.id ? "#00d4ff11" : "transparent",
              color: activeSkill === s.id ? "#00d4ff" : "#444",
              cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap",
            }}>{s.icon} {s.name}</button>
          ))}
        </div>

        {/* Mode toggle */}
        <div style={{ display: "flex", background: "#0d0d1a", borderRadius: 7, border: "1px solid #1a1a2a", padding: 2 }}>
          {["Director", "Autopilot"].map(m => (
            <button key={m} onClick={() => setMode(m)} className="btn" style={{
              padding: "3px 10px", borderRadius: 5, fontSize: 10, fontWeight: 700,
              border: "none", background: mode === m ? "#00d4ff1a" : "transparent",
              color: mode === m ? "#00d4ff" : "#444", cursor: "pointer", fontFamily: "inherit",
            }}>{m}</button>
          ))}
        </div>

        {/* Intelligence badges */}
        <div style={{ display: "flex", gap: 4 }}>
          <span style={{ fontSize: 9, padding: "3px 7px", borderRadius: 4, background: "#00d4ff11", border: "1px solid #00d4ff22", color: "#00d4ff" }}>Claude</span>
          <span style={{ fontSize: 9, padding: "3px 7px", borderRadius: 4, background: "#fbbc0411", border: "1px solid #fbbc0422", color: "#fbbc04" }}>Gemini</span>
        </div>
      </div>

      {/* ── BODY ── */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>

        {/* ── LEFT NAV ── */}
        <div style={{ width: 48, background: "#06060e", borderRight: "1px solid #111118", display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 8, gap: 2, flexShrink: 0 }}>
          {NAV.map(n => (
            <button key={n.id} onClick={() => setView(n.id)} title={n.label}
              className={`nav-item${view === n.id ? " active" : ""}`}
              style={{
                width: 40, height: 40, borderRadius: 8, border: "none",
                background: view === n.id ? "#0d0d1a" : "transparent",
                color: view === n.id ? "#00d4ff" : "#333",
                cursor: "pointer", fontSize: 14, fontFamily: "inherit",
                borderLeft: view === n.id ? "2px solid #00d4ff" : "2px solid transparent",
                display: "flex", alignItems: "center", justifyContent: "center",
                transition: "all 0.15s",
              }}>{n.icon}</button>
          ))}
        </div>

        {/* ── SCENE SIDEBAR (only in chat view) ── */}
        {view === "chat" && (
          <div style={{ width: 200, background: "#06060e", borderRight: "1px solid #111118", display: "flex", flexDirection: "column", flexShrink: 0 }}>
            <div style={{ padding: "10px 12px 6px", fontSize: 9, fontWeight: 700, letterSpacing: 2, color: "#333", textTransform: "uppercase" }}>
              Scenes · {scenes.length}
            </div>
            <div style={{ flex: 1, overflowY: "auto", padding: "0 8px 8px" }}>
              {scenes.map((s, i) => (
                <div key={i} onClick={() => setSelectedScene(i)} style={{
                  padding: "8px 10px", borderRadius: 8, marginBottom: 5, cursor: "pointer",
                  background: selectedScene === i ? "#0d0d1a" : "transparent",
                  border: `1px solid ${selectedScene === i ? "#00d4ff33" : "transparent"}`,
                  transition: "all 0.15s",
                }}>
                  <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 3 }}>
                    <div style={{
                      width: 6, height: 6, borderRadius: "50%",
                      background: s.model ? (MODELS.video.find(m=>m.id===s.model)?.color || "#555") : "#333",
                    }} />
                    <span style={{ fontSize: 9, color: "#444", fontWeight: 700, letterSpacing: 1 }}>S{i+1}</span>
                    {s.model && <span style={{ fontSize: 9, color: "#555" }}>{s.model}</span>}
                  </div>
                  <div style={{ fontSize: 11, color: "#888", lineHeight: 1.4 }}>{s.title || `Scene ${i+1}`}</div>
                </div>
              ))}
              {!scenes.length && <div style={{ color: "#1a1a2a", fontSize: 11, padding: "16px 8px", textAlign: "center" }}>Brief the Director</div>}
            </div>

            {/* Agent crew status */}
            <div style={{ borderTop: "1px solid #111118", padding: "8px 10px" }}>
              <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 2, color: "#333", marginBottom: 6, textTransform: "uppercase" }}>Crew</div>
              {agentSteps.slice(-4).map((s, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                  <div style={{
                    width: 5, height: 5, borderRadius: "50%",
                    background: s.status === "running" ? agentColor(s.agentId) : s.status === "done" ? "#00ff88" : "#333",
                    animation: s.status === "running" ? "pulse 1s infinite" : "none",
                  }} />
                  <span style={{ fontSize: 9, color: "#555", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {s.msg}
                  </span>
                </div>
              ))}
              {!agentSteps.length && <div style={{ fontSize: 9, color: "#1a1a2a" }}>Idle</div>}
            </div>
          </div>
        )}

        {/* ── MAIN CONTENT AREA ── */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>

          {/* CHAT VIEW */}
          {view === "chat" && (
            <>
              <div ref={chatRef} style={{ flex: 1, overflowY: "auto", padding: "20px 24px", display: "flex", flexDirection: "column", gap: 16 }}>
                {!messages.length && (
                  <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", gap: 20, padding: 40 }}>
                    <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: 28, lineHeight: 1.2, maxWidth: 400 }}>
                      <span style={{ color: "#00d4ff" }}>Director Agent</span><br />
                      <span style={{ color: "#333" }}>ready to build with you</span>
                    </div>
                    <div style={{ color: "#333", fontSize: 12, lineHeight: 1.8, maxWidth: 360 }}>
                      Tell me what you're making. I know your projects, your brand, your platform.<br />
                      I'll plan, brainstorm, route every model, and build the full production.
                    </div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", maxWidth: 500 }}>
                      {[
                        "YouTube Short — AI taking creative jobs, Port Harcourt perspective",
                        "Brainstorm angles for Creator Factory launch campaign",
                        "Music video concept for my next NBA Josh drop",
                        "NFT reveal video for Mudworld collection",
                        "Viral TikTok hook for Creator Factory waitlist",
                      ].map((s, i) => (
                        <button key={i} onClick={() => setInput(s)} style={{
                          fontSize: 11, padding: "7px 12px", borderRadius: 8,
                          background: "#0a0a14", border: "1px solid #1a1a2a",
                          color: "#555", cursor: "pointer", fontFamily: "inherit",
                          textAlign: "left", transition: "all 0.15s", lineHeight: 1.4,
                        }}>{s}</button>
                      ))}
                    </div>
                  </div>
                )}

                {messages.map((msg, i) => (
                  <div key={i} className="msg" style={{ display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start", gap: 10 }}>
                    {msg.role !== "user" && (
                      <div style={{
                        width: 26, height: 26, borderRadius: 7, flexShrink: 0, marginTop: 3,
                        background: "linear-gradient(135deg, #00d4ff22, #a855f722)",
                        border: "1px solid #00d4ff33",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 10,
                      }}>◎</div>
                    )}
                    <div style={{ maxWidth: "78%" }}>
                      <div style={{
                        background: msg.role === "user" ? "#0c1a2a" : "#090914",
                        border: `1px solid ${msg.role === "user" ? "#00d4ff22" : "#1a1a2a"}`,
                        borderRadius: msg.role === "user" ? "14px 3px 14px 14px" : "3px 14px 14px 14px",
                        padding: "12px 16px", fontSize: 13, lineHeight: 1.7, color: "#c0c0d0",
                        whiteSpace: "pre-wrap",
                      }}>
                        {msg.content}
                      </div>
                      {/* Alternatives */}
                      {msg.alternatives?.length > 0 && (
                        <div style={{ marginTop: 10 }}>
                          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 2, color: "#444", marginBottom: 6, textTransform: "uppercase" }}>Alternative Concepts</div>
                          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                            {msg.alternatives.map((alt, j) => (
                              <button key={j} onClick={() => setInput(`Let's go with: ${alt.title} — ${alt.concept}`)}
                                style={{
                                  fontSize: 11, padding: "6px 10px", borderRadius: 8,
                                  background: "#0a0a14", border: "1px solid #00d4ff22",
                                  color: "#888", cursor: "pointer", fontFamily: "inherit",
                                  textAlign: "left", maxWidth: 200, lineHeight: 1.4,
                                }}>
                                <div style={{ color: "#00d4ff", fontWeight: 600, marginBottom: 2 }}>{alt.title}</div>
                                <div style={{ fontSize: 10, color: "#555" }}>{alt.concept}</div>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                      {/* Brainstorm bullets */}
                      {msg.brainstorm?.length > 0 && (
                        <div style={{ marginTop: 8, padding: "8px 12px", background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 8 }}>
                          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 2, color: "#444", marginBottom: 6, textTransform: "uppercase" }}>Brainstorm Pool</div>
                          {msg.brainstorm.map((b, j) => (
                            <div key={j} style={{ fontSize: 11, color: "#666", marginBottom: 3, display: "flex", gap: 6 }}>
                              <span style={{ color: "#333" }}>—</span> {b}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}

                {isRunning && (
                  <div className="msg" style={{ display: "flex", gap: 10 }}>
                    <div style={{
                      width: 26, height: 26, borderRadius: 7, flexShrink: 0,
                      background: "linear-gradient(135deg, #00d4ff22, #a855f722)",
                      border: "1px solid #00d4ff33",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 10, animation: "glow 2s ease infinite",
                    }}>◎</div>
                    <div style={{ background: "#090914", border: "1px solid #1a1a2a", borderRadius: "3px 14px 14px 14px", padding: "12px 16px" }}>
                      <div style={{ display: "flex", gap: 8, flexDirection: "column" }}>
                        {AGENTS.filter(a => agentSteps.some(s => s.agentId === a.id)).map(a => {
                          const step = agentSteps.filter(s => s.agentId === a.id).slice(-1)[0];
                          return (
                            <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                              <div style={{
                                width: 6, height: 6, borderRadius: "50%", background: a.color, flexShrink: 0,
                                animation: step?.status === "running" ? "pulse 1s infinite" : "none",
                              }} />
                              <span style={{ fontSize: 11, color: a.color, fontWeight: 600, minWidth: 80 }}>{a.name}</span>
                              <span style={{ fontSize: 11, color: "#555" }}>{step?.msg}</span>
                              {step?.status === "done" && <span style={{ fontSize: 11, color: "#00ff88" }}>✓</span>}
                            </div>
                          );
                        })}
                        {agentSteps.length === 0 && (
                          <div style={{ display: "flex", gap: 4 }}>
                            {[0,1,2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: "#00d4ff", animation: `bounce 1.2s ease-in-out ${i*0.2}s infinite` }} />)}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Scene detail */}
              {scenes[selectedScene] && (
                <div style={{ borderTop: "1px solid #111118", padding: "10px 20px", background: "#070710", display: "flex", gap: 16, overflowX: "auto", flexShrink: 0 }}>
                  {[
                    { label: "Scene", val: `${selectedScene+1} · ${scenes[selectedScene].title}` },
                    { label: "Shot", val: scenes[selectedScene].shot },
                    { label: "Model", val: scenes[selectedScene].model, color: MODELS.video.find(m=>m.id===scenes[selectedScene].model)?.color },
                    { label: "VO", val: scenes[selectedScene].vo || scenes[selectedScene].voiceover, italic: true },
                    { label: "Prompt", val: scenes[selectedScene].visualPrompt, color: "#a855f7" },
                  ].filter(f=>f.val).map((f,i) => (
                    <div key={i} style={{ flexShrink: 0, maxWidth: 180 }}>
                      <div style={{ fontSize: 8, fontWeight: 700, letterSpacing: 2, color: "#333", textTransform: "uppercase", marginBottom: 3 }}>{f.label}</div>
                      <div style={{ fontSize: 11, color: f.color || "#777", fontStyle: f.italic ? "italic" : "normal", lineHeight: 1.5 }}>{f.val?.toString().slice(0,100)}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Input */}
              <div style={{ padding: "12px 16px", background: "#07070f", borderTop: "1px solid #111118", flexShrink: 0 }}>
                <div style={{ background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 12, padding: "10px 14px" }}>
                  <textarea
                    ref={inputRef} value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={handleKey}
                    placeholder={`Brief the Director · active skill: ${CREATOR_SKILLS.find(s=>s.id===activeSkill)?.name} · mode: ${mode}`}
                    rows={2}
                    style={{ background: "transparent", border: "none", color: "#e0e0f0", fontSize: 13, fontFamily: "inherit", resize: "none", lineHeight: 1.6, width: "100%" }}
                  />
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6 }}>
                    <span style={{ fontSize: 9, padding: "2px 7px", borderRadius: 4, background: "#00d4ff11", border: "1px solid #00d4ff22", color: "#00d4ff", letterSpacing: 1 }}>
                      {CREATOR_SKILLS.find(s=>s.id===activeSkill)?.icon} {CREATOR_SKILLS.find(s=>s.id===activeSkill)?.name}
                    </span>
                    <span style={{ fontSize: 9, color: "#333" }}>{mode}</span>
                    <div style={{ flex: 1 }} />
                    <span style={{ fontSize: 9, color: "#1a1a2a" }}>↵ send</span>
                    <button onClick={send} disabled={isRunning || !input.trim()} style={{
                      padding: "5px 14px", borderRadius: 8, fontSize: 11, fontWeight: 700,
                      background: isRunning || !input.trim() ? "#1a1a2a" : "#00d4ff",
                      border: "none", color: isRunning || !input.trim() ? "#333" : "#000",
                      cursor: isRunning || !input.trim() ? "not-allowed" : "pointer", fontFamily: "inherit",
                    }}>{isRunning ? "Running..." : "Send"}</button>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* CANVAS VIEW */}
          {view === "canvas" && (
            <NodeCanvas nodes={nodes} connections={nodeConnections}
              onAddNode={addNode} onMoveNode={moveNode}
              onSelectNode={setSelectedNode} selectedNode={selectedNode} />
          )}

          {/* MOODBOARD VIEW */}
          {view === "moodboard" && (
            <MoodBoard assets={assets}
              onAddAsset={a => setAssets(prev => [...prev, a])}
              onRemoveAsset={id => setAssets(prev => prev.filter(a => a.id !== id))} />
          )}

          {/* TERMINAL VIEW */}
          {view === "terminal" && (
            <Terminal scenes={scenes} brain={brain} projectName={projectName} />
          )}

          {/* AGENTS VIEW */}
          {view === "agents" && (
            <div style={{ padding: 24, overflowY: "auto" }}>
              <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: 18, marginBottom: 4 }}>Agent Crew</div>
              <div style={{ fontSize: 12, color: "#444", marginBottom: 24 }}>Multi-agent pipeline — each agent is a specialized intelligence</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 12 }}>
                {AGENTS.map(a => {
                  const step = agentSteps.filter(s => s.agentId === a.id).slice(-1)[0];
                  return (
                    <div key={a.id} style={{
                      background: "#0a0a14", border: `1px solid ${step?.status === "running" ? a.color + "44" : "#1a1a2a"}`,
                      borderRadius: 12, padding: "16px 18px",
                      boxShadow: step?.status === "running" ? `0 0 20px ${a.color}22` : "none",
                      transition: "all 0.3s",
                    }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                        <div style={{
                          width: 36, height: 36, borderRadius: 10,
                          background: a.color + "11", border: `1px solid ${a.color}33`,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 16, color: a.color,
                        }}>{a.icon}</div>
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 600, color: "#e0e0f0" }}>{a.name}</div>
                          <div style={{ fontSize: 10, color: "#555" }}>{a.role}</div>
                        </div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <div style={{
                          width: 6, height: 6, borderRadius: "50%",
                          background: step?.status === "running" ? a.color : step?.status === "done" ? "#00ff88" : "#2a2a3a",
                          animation: step?.status === "running" ? "pulse 1s infinite" : "none",
                        }} />
                        <span style={{ fontSize: 10, color: "#555" }}>
                          {step?.status === "running" ? step.msg : step?.status === "done" ? step.msg : "Idle"}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div style={{ marginTop: 32 }}>
                <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 16 }}>Creator Skills</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 8 }}>
                  {CREATOR_SKILLS.map(s => (
                    <button key={s.id} onClick={() => setActiveSkill(s.id)} style={{
                      background: activeSkill === s.id ? "#00d4ff0a" : "#0a0a14",
                      border: `1px solid ${activeSkill === s.id ? "#00d4ff33" : "#1a1a2a"}`,
                      borderRadius: 10, padding: "12px 14px", cursor: "pointer", fontFamily: "inherit",
                      textAlign: "left", transition: "all 0.15s",
                    }}>
                      <div style={{ fontSize: 18, marginBottom: 6 }}>{s.icon}</div>
                      <div style={{ fontSize: 12, fontWeight: 600, color: "#c0c0d0", marginBottom: 4 }}>{s.name}</div>
                      <div style={{ fontSize: 10, color: "#555", lineHeight: 1.4 }}>{s.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ marginTop: 32 }}>
                <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 16 }}>Available Models</div>
                {Object.entries(MODELS).map(([type, list]) => (
                  <div key={type} style={{ marginBottom: 20 }}>
                    <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 2, color: "#444", textTransform: "uppercase", marginBottom: 8 }}>{type}</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                      {list.map(m => (
                        <div key={m.id} style={{
                          padding: "6px 12px", borderRadius: 8,
                          background: m.color + "11", border: `1px solid ${m.color}33`,
                          fontSize: 11,
                        }}>
                          <span style={{ color: m.color, fontWeight: 600 }}>{m.name}</span>
                          <span style={{ color: "#444", marginLeft: 6, fontSize: 10 }}>{m.best}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* MCP VIEW */}
          {view === "mcp" && (
            <div style={{ padding: 24, overflowY: "auto" }}>
              <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: 18, marginBottom: 4 }}>MCP Connections</div>
              <div style={{ fontSize: 12, color: "#444", marginBottom: 24 }}>Model Context Protocol — connect agents to your tools and services</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 10 }}>
                {MCP_TOOLS.map(t => (
                  <div key={t.id} style={{
                    background: "#0a0a14", border: `1px solid ${t.status === "connected" ? t.color + "33" : "#1a1a2a"}`,
                    borderRadius: 12, padding: "14px 16px",
                  }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                      <div style={{
                        width: 32, height: 32, borderRadius: 8,
                        background: t.color + "11", border: `1px solid ${t.color}33`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 14, color: t.color,
                      }}>{t.icon}</div>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 600, color: "#c0c0d0" }}>{t.name}</div>
                        <div style={{ fontSize: 9, color: t.status === "connected" ? "#00ff88" : "#444", fontWeight: 600, letterSpacing: 1, textTransform: "uppercase" }}>
                          {t.status}
                        </div>
                      </div>
                    </div>
                    <button style={{
                      width: "100%", padding: "5px 0", borderRadius: 6, fontSize: 10, fontWeight: 600,
                      background: t.status === "connected" ? "#00ff8811" : "#1a1a2a",
                      border: `1px solid ${t.status === "connected" ? "#00ff8833" : "#2a2a3a"}`,
                      color: t.status === "connected" ? "#00ff88" : "#555",
                      cursor: "pointer", fontFamily: "inherit",
                    }}>{t.status === "connected" ? "● Connected" : "Connect"}</button>
                  </div>
                ))}
              </div>

              <div style={{ marginTop: 32, background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 12, padding: 20 }}>
                <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, fontSize: 13, marginBottom: 12 }}>CLI Quick Reference</div>
                <div style={{ fontFamily: "DM Mono, monospace", fontSize: 11, color: "#555", lineHeight: 2 }}>
                  {`$ cf agents list          — list all agents
$ cf scene generate [n]  — generate scene N
$ cf model route         — auto-route all scenes
$ cf export json         — export production plan
$ cf mcp connect [tool]  — connect MCP tool
$ cf brain set [key]     — update brain memory
$ cf run pipeline        — run full agent pipeline
$ cf brainstorm [topic]  — quick brainstorm session`}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ── RIGHT PANEL: BRAIN ── */}
        {view === "chat" && (
          <div style={{ width: 220, background: "#06060e", borderLeft: "1px solid #111118", display: "flex", flexDirection: "column", flexShrink: 0 }}>
            <div style={{ padding: "10px 12px 6px", fontSize: 9, fontWeight: 700, letterSpacing: 2, color: "#333", textTransform: "uppercase" }}>
              Agent Brain
            </div>
            <div style={{ flex: 1, overflowY: "auto", padding: "0 10px" }}>
              {[
                { key: "rules", label: "Rules", color: "#ffaa00" },
                { key: "worldBuilding", label: "World", color: "#00d4ff" },
                { key: "characters", label: "Characters", color: "#a855f7" },
                { key: "brand", label: "Brand", color: "#00ff88" },
                { key: "knowledge", label: "Knowledge", color: "#ff6b35" },
              ].map(f => (
                <div key={f.key} style={{ marginBottom: 12 }}>
                  <div style={{ fontSize: 8, fontWeight: 700, letterSpacing: 1.5, color: f.color, textTransform: "uppercase", marginBottom: 4 }}>{f.label}</div>
                  <textarea
                    value={brain[f.key]}
                    onChange={e => setBrain(prev => ({ ...prev, [f.key]: e.target.value }))}
                    placeholder={`+ ${f.label.toLowerCase()}...`}
                    rows={2}
                    style={{
                      width: "100%", background: "#0a0a14", border: "1px solid #1a1a2a",
                      borderRadius: 6, color: "#888", fontSize: 10, padding: "6px 8px",
                      fontFamily: "inherit", resize: "none", lineHeight: 1.5,
                    }}
                  />
                </div>
              ))}
            </div>

            {/* Export */}
            {scenes.length > 0 && (
              <div style={{ padding: 10, borderTop: "1px solid #111118" }}>
                <button onClick={() => {
                  const d = { project: projectName, brain, scenes, exported: new Date().toISOString() };
                  const b = new Blob([JSON.stringify(d, null, 2)], { type: "application/json" });
                  const url = URL.createObjectURL(b);
                  const a = document.createElement("a");
                  a.href = url; a.download = `${projectName.replace(/\s+/g,"_")}.json`; a.click();
                }} style={{
                  width: "100%", padding: "7px 0", borderRadius: 7, fontSize: 10, fontWeight: 700,
                  background: "#00d4ff11", border: "1px solid #00d4ff22", color: "#00d4ff",
                  cursor: "pointer", fontFamily: "inherit",
                }}>↓ Export JSON</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
