## Shopify ↔ TikTok bridge (no TikTok Shop required)

A single app that connects your Shopify store to TikTok as a traffic + content channel — without ever joining TikTok Shop. Buyers always check out on infrastructure you own (Shopify), so no SSN/EIN is ever submitted to TikTok.

### What you get

1. **Shoppable link-in-bio page** — one URL for your TikTok bio, branded, lists your Shopify products, taps go straight to a custom checkout.
2. **TikTok-style vertical product feed** — swipeable, video-first storefront on your domain so TikTok visitors land somewhere familiar.
3. **Custom checkout** — built on Shopify's Storefront with toggle for TikTok store front API (cart + checkout still processed by Shopify or TikTok depends on customers preference just with our UI).
4. **Auto-post products to TikTok** — when you add or update a Shopify product, a TikTok video/photo post is published automatically with a link back to the product.
5. **Click & conversion tracking** — UTM-tagged links + a dashboard showing TikTok clicks → Shopify orders.
6. Optimization and monetization 

### How it works (plain language)

```text
Shopify (your store, your products, your money)
        │
        ├──► Storefront API ──► Link-in-bio page + Vertical feed + Custom checkout
        │
        └──► Webhook on product create/update
                       │
                       ▼
              Our server picks media + caption
                       │
                       ▼
              TikTok Content Posting API ──► Video/photo posted to your TikTok
                       │
                       ▼
              Caption includes UTM link back to your product on Shopify
```

No product data, customer data, or payments ever touch TikTok Shop. TikTok only sees the public marketing post.

### Pages in the app

- `/` — Landing/marketing page explaining the tool (your dashboard home).
- `/admin` — Connect Shopify, connect TikTok, see synced products, see analytics.
- `/admin/posts` — Queue of auto-generated TikTok posts; approve, edit caption, or auto-publish.
- `/admin/analytics` — Clicks, top products, TikTok-attributed Shopify orders.
- `/shop` — Public TikTok-style vertical product feed (your shoppable destination).
- `/shop/$handle` — Product detail page.
- `/bio` — Minimal link-in-bio page optimized for the TikTok in-app browser.
- `/cart` and `/checkout` — Custom checkout flow built on Shopify Storefront API.
- `/r/$productHandle` — Short redirect URL with UTM tagging (for TikTok captions).

### What you'll need to provide (one-time setup, in-app)

1. **Shopify**: Admin API access token + Storefront API access token from your Shopify admin (Apps → Develop apps → custom app). I'll show exact steps in-app.
2. **TikTok**: Approval for a TikTok for Developers app with the **Content Posting API** scope. This uses your normal TikTok account — no Shop, no SSN. (Approval usually takes 1–3 business days from TikTok.)
3. **Lovable Cloud**: enabled for storing your settings, post queue, click logs, and order attribution. Auth so only you access `/admin`.

### Important constraints (so there are no surprises)

- **TikTok Content Posting API approval is required** before auto-posting works. Until approved, the app generates the posts and lets you copy/download them to post manually — so you're not blocked.
- **In-feed shoppable tags / TikTok Shop checkout are not possible** without a TikTok Shop seller account. We use bio link + caption link instead, which is the standard playbook for non-Shop sellers.
- **TikTok clamps outbound links** for new accounts; the `/r/...` redirector keeps URLs short and trackable regardless.

### Tech notes (for the curious)

- TanStack Start with server functions for Shopify Admin + Storefront API calls and TikTok API calls (keeps tokens server-side).
- Shopify product webhook → server route under `/api/public/shopify/webhook` with HMAC verification.
- Inngest connector for the durable post-generation + publish workflow (retries, scheduling).
- Lovable Cloud (Supabase) tables: `settings`, `tiktok_posts`, `clicks`, `orders_attributed`. RLS so only the owner reads them.
- Custom checkout uses Shopify Storefront API `cartCreate` → `cartLinesAdd` → redirect to Shopify-hosted `checkoutUrl` (PCI stays with Shopify).

### Build order

1. Scaffold pages + Lovable Cloud + owner auth.
2. Shopify connection + product sync + Storefront API checkout.
3. Public `/shop` vertical feed, `/bio` page, `/r/...` redirector with UTM.
4. Click + order attribution + analytics dashboard.
5. TikTok OAuth + Content Posting API + Inngest workflow for auto-post on product webhook.
6. Post queue UI with manual approve/edit fallback for pre-approval period.