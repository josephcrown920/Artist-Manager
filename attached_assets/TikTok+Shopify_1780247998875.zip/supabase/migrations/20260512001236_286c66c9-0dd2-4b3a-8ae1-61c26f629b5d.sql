
-- Roles enum + table
create type public.app_role as enum ('admin', 'user');

create table public.profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

create table public.settings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  shopify_domain text,
  shopify_storefront_token text,
  shopify_admin_token text,
  tiktok_handle text,
  tiktok_access_token text,
  tiktok_refresh_token text,
  tiktok_pixel_id text,
  auto_publish boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create type public.post_status as enum ('draft', 'scheduled', 'published', 'failed');

create table public.tiktok_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_handle text,
  product_title text,
  caption text,
  thumbnail_url text,
  video_url text,
  status post_status not null default 'draft',
  scheduled_for timestamptz,
  published_at timestamptz,
  tiktok_post_id text,
  views integer not null default 0,
  clicks integer not null default 0,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.clicks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_handle text,
  source text,
  utm_campaign text,
  utm_medium text,
  utm_content text,
  country text,
  device text,
  referrer text,
  created_at timestamptz not null default now()
);
create index idx_clicks_user_created on public.clicks(user_id, created_at desc);

create table public.orders_attributed (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  shopify_order_id text not null,
  product_handle text,
  total numeric(12,2) not null default 0,
  currency text not null default 'USD',
  utm_campaign text,
  created_at timestamptz not null default now(),
  unique (user_id, shopify_order_id)
);

-- has_role security definer function
create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- updated_at trigger fn
create or replace function public.update_updated_at_column()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;

create trigger trg_profiles_updated before update on public.profiles
  for each row execute function public.update_updated_at_column();
create trigger trg_settings_updated before update on public.settings
  for each row execute function public.update_updated_at_column();
create trigger trg_posts_updated before update on public.tiktok_posts
  for each row execute function public.update_updated_at_column();

-- Auto-create profile + default user role on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (user_id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)));
  insert into public.user_roles (user_id, role) values (new.id, 'user');
  return new;
end; $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Enable RLS
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.settings enable row level security;
alter table public.tiktok_posts enable row level security;
alter table public.clicks enable row level security;
alter table public.orders_attributed enable row level security;

-- profiles
create policy "Profiles viewable by owner" on public.profiles for select using (auth.uid() = user_id);
create policy "Users insert own profile" on public.profiles for insert with check (auth.uid() = user_id);
create policy "Users update own profile" on public.profiles for update using (auth.uid() = user_id);

-- user_roles (admins manage; users read their own)
create policy "Users see own roles" on public.user_roles for select using (auth.uid() = user_id);
create policy "Admins manage roles" on public.user_roles for all
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- settings (owner CRUD)
create policy "Owner select settings" on public.settings for select using (auth.uid() = user_id);
create policy "Owner insert settings" on public.settings for insert with check (auth.uid() = user_id);
create policy "Owner update settings" on public.settings for update using (auth.uid() = user_id);
create policy "Owner delete settings" on public.settings for delete using (auth.uid() = user_id);

-- tiktok_posts (owner CRUD)
create policy "Owner select posts" on public.tiktok_posts for select using (auth.uid() = user_id);
create policy "Owner insert posts" on public.tiktok_posts for insert with check (auth.uid() = user_id);
create policy "Owner update posts" on public.tiktok_posts for update using (auth.uid() = user_id);
create policy "Owner delete posts" on public.tiktok_posts for delete using (auth.uid() = user_id);

-- clicks (owner read; inserts allowed by owner — webhooks use service role)
create policy "Owner select clicks" on public.clicks for select using (auth.uid() = user_id);
create policy "Owner insert clicks" on public.clicks for insert with check (auth.uid() = user_id);

-- orders_attributed (owner read; webhook writes via service role)
create policy "Owner select orders" on public.orders_attributed for select using (auth.uid() = user_id);
create policy "Owner insert orders" on public.orders_attributed for insert with check (auth.uid() = user_id);
