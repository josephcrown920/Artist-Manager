import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2, AlertCircle, Plug, Video, Eye, MousePointerClick, ShoppingBag, ArrowUpRight } from "lucide-react";
import { mockProducts, mockAnalytics } from "@/lib/mock-data";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [{ title: "Admin · SHOPTOK" }],
  }),
  component: AdminHome,
});

function AdminHome() {
  return (
    <div className="p-6 md:p-10 space-y-8 max-w-7xl">
      <header>
        <div className="text-mono text-xs uppercase tracking-widest text-muted-foreground">Dashboard</div>
        <h1 className="text-display text-4xl font-bold mt-1">Welcome back.</h1>
        <p className="text-muted-foreground mt-2 text-sm">Here's what your bridge has been doing.</p>
      </header>

      {/* Connections */}
      <section className="grid gap-4 md:grid-cols-2">
        <ConnectionCard
          name="Shopify"
          status="disconnected"
          description="Connect your store to start syncing products."
          actionLabel="Connect store"
        />
        <ConnectionCard
          name="TikTok"
          status="pending"
          description="Awaiting Content Posting API approval. Drafts work in the meantime."
          actionLabel="Manage TikTok"
        />
      </section>

      {/* Stats */}
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="TikTok clicks" value={mockAnalytics.totals.tiktokClicks.toLocaleString()} delta="+18.4%" icon={MousePointerClick} accent="magenta" />
        <StatCard label="Sessions" value={mockAnalytics.totals.sessions.toLocaleString()} delta="+12.1%" icon={Eye} accent="lime" />
        <StatCard label="Orders" value={mockAnalytics.totals.orders.toLocaleString()} delta="+24.0%" icon={ShoppingBag} accent="cyan" />
        <StatCard label="Revenue" value={`$${mockAnalytics.totals.revenue.toLocaleString()}`} delta="+31.2%" icon={ArrowUpRight} accent="magenta" />
      </section>

      {/* Recent products */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-display text-2xl font-bold">Synced products</h2>
          <Link to="/admin/posts" className="text-xs text-muted-foreground hover:text-foreground transition flex items-center gap-1">
            <Video className="h-3.5 w-3.5" /> Generate posts
          </Link>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {mockProducts.slice(0, 6).map((p) => (
            <div key={p.id} className="group flex gap-3 rounded-xl border border-border bg-card p-3 hover:border-primary/40 transition">
              <img src={p.image} alt={p.title} className="h-16 w-16 rounded-lg object-cover" />
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm truncate">{p.title}</div>
                <div className="text-xs text-muted-foreground">${p.price} · {p.inventory} in stock</div>
                <div className="text-mono text-[10px] text-accent mt-1">/{p.handle}</div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function ConnectionCard({
  name,
  status,
  description,
  actionLabel,
}: {
  name: string;
  status: "connected" | "disconnected" | "pending";
  description: string;
  actionLabel: string;
}) {
  const statusMeta = {
    connected: { color: "text-accent", bg: "bg-accent/10", icon: CheckCircle2, label: "Connected" },
    disconnected: { color: "text-destructive", bg: "bg-destructive/10", icon: AlertCircle, label: "Not connected" },
    pending: { color: "text-yellow-400", bg: "bg-yellow-400/10", icon: AlertCircle, label: "Pending approval" },
  }[status];

  const Icon = statusMeta.icon;

  return (
    <div className="rounded-2xl border border-border bg-card p-6 flex items-start justify-between gap-4">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-lg bg-secondary flex items-center justify-center">
            <Plug className="h-4 w-4" />
          </div>
          <div>
            <div className="font-semibold">{name}</div>
            <div className={`flex items-center gap-1 text-xs ${statusMeta.color}`}>
              <Icon className="h-3 w-3" />
              {statusMeta.label}
            </div>
          </div>
        </div>
        <p className="mt-3 text-sm text-muted-foreground">{description}</p>
      </div>
      <button className="rounded-full bg-primary px-4 py-1.5 text-xs font-semibold text-primary-foreground hover:opacity-90 transition shrink-0">
        {actionLabel}
      </button>
    </div>
  );
}

function StatCard({
  label,
  value,
  delta,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string;
  delta: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: "magenta" | "lime" | "cyan";
}) {
  const accentClass = {
    magenta: "text-primary",
    lime: "text-accent",
    cyan: "text-cyan",
  }[accent];

  return (
    <div className="rounded-2xl border border-border bg-card p-5 hover:bg-surface-elevated transition">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">{label}</span>
        <Icon className={`h-4 w-4 ${accentClass}`} />
      </div>
      <div className="text-display text-3xl font-bold mt-2">{value}</div>
      <div className="text-xs text-accent mt-1">{delta} vs last week</div>
    </div>
  );
}
