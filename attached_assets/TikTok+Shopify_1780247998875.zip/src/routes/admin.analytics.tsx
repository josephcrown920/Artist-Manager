import { createFileRoute } from "@tanstack/react-router";
import { mockAnalytics } from "@/lib/mock-data";
import { TrendingUp, MousePointerClick, ShoppingBag, DollarSign, Percent } from "lucide-react";

export const Route = createFileRoute("/admin/analytics")({
  head: () => ({ meta: [{ title: "Analytics · SHOPTOK" }] }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const max = Math.max(...mockAnalytics.daily.map((d) => d.clicks));

  return (
    <div className="p-6 md:p-10 space-y-8 max-w-7xl">
      <header>
        <div className="text-mono text-xs uppercase tracking-widest text-muted-foreground">Attribution</div>
        <h1 className="text-display text-4xl font-bold mt-1">TikTok → Shopify</h1>
        <p className="text-muted-foreground mt-2 text-sm">What your TikTok content is actually selling.</p>
      </header>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Tile icon={MousePointerClick} label="Clicks" value={mockAnalytics.totals.tiktokClicks.toLocaleString()} />
        <Tile icon={TrendingUp} label="Sessions" value={mockAnalytics.totals.sessions.toLocaleString()} />
        <Tile icon={ShoppingBag} label="Orders" value={mockAnalytics.totals.orders.toLocaleString()} />
        <Tile icon={DollarSign} label="Revenue" value={`$${mockAnalytics.totals.revenue.toLocaleString()}`} />
        <Tile icon={Percent} label="CVR" value={`${mockAnalytics.totals.conversionRate}%`} />
      </section>

      {/* Daily chart */}
      <section className="rounded-2xl border border-border bg-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-display text-xl font-bold">Last 7 days</h2>
            <p className="text-xs text-muted-foreground">Clicks vs orders</p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-primary" /> Clicks</span>
            <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-accent" /> Orders</span>
          </div>
        </div>
        <div className="flex items-end gap-3 h-64">
          {mockAnalytics.daily.map((d) => (
            <div key={d.date} className="flex-1 flex flex-col items-center gap-2">
              <div className="w-full flex items-end justify-center gap-1 h-full">
                <div
                  className="w-1/2 rounded-t bg-gradient-to-t from-primary to-primary/40 transition hover:from-primary"
                  style={{ height: `${(d.clicks / max) * 100}%` }}
                  title={`${d.clicks} clicks`}
                />
                <div
                  className="w-1/2 rounded-t bg-gradient-to-t from-accent to-accent/40 transition"
                  style={{ height: `${(d.orders / max) * 100 * 30}%` }}
                  title={`${d.orders} orders`}
                />
              </div>
              <div className="text-mono text-xs text-muted-foreground">{d.date}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Top products */}
      <section className="rounded-2xl border border-border bg-card p-6">
        <h2 className="text-display text-xl font-bold mb-4">Top products from TikTok</h2>
        <div className="space-y-3">
          {mockAnalytics.topProducts.map((p, i) => {
            const maxClicks = mockAnalytics.topProducts[0].clicks;
            return (
              <div key={p.handle} className="flex items-center gap-4">
                <div className="text-display text-2xl font-bold text-muted-foreground w-8">{i + 1}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="font-medium truncate">{p.title}</span>
                    <span className="text-muted-foreground text-xs">{p.clicks.toLocaleString()} clicks · {p.orders} orders</span>
                  </div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <div className="h-full bg-gradient-hero" style={{ width: `${(p.clicks / maxClicks) * 100}%` }} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}

function Tile({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <Icon className="h-4 w-4 text-accent" />
      <div className="text-display text-2xl font-bold mt-3">{value}</div>
      <div className="text-xs text-muted-foreground mt-1">{label}</div>
    </div>
  );
}
