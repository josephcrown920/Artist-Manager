import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles, Zap, ShoppingBag, BarChart3, Video, Lock } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SHOPTOK — Sell on TikTok without TikTok Shop" },
      { name: "description", content: "Auto-post your Shopify products to TikTok and convert viewers with a custom checkout. No SSN. No Shop seller account. Just sales." },
      { property: "og:title", content: "SHOPTOK — Shopify × TikTok, no Shop required" },
      { property: "og:description", content: "Bridge your Shopify store to TikTok traffic. Built for creators who can't (or won't) join TikTok Shop." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground noise overflow-hidden">
      {/* Nav */}
      <nav className="relative z-20 flex items-center justify-between px-6 py-5 md:px-12">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-hero shadow-glow-magenta">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-display font-bold tracking-tight">SHOPTOK</span>
        </Link>
        <div className="hidden items-center gap-6 md:flex text-sm">
          <a href="#how" className="text-muted-foreground hover:text-foreground transition">How it works</a>
          <a href="#features" className="text-muted-foreground hover:text-foreground transition">Features</a>
          <Link to="/shop" className="text-muted-foreground hover:text-foreground transition">Demo store</Link>
        </div>
        <Link
          to="/admin"
          className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-glow-magenta hover:opacity-90 transition"
        >
          Open dashboard <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </nav>

      {/* Hero */}
      <section className="relative px-6 pb-24 pt-12 md:px-12 md:pt-20">
        <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
        <div className="absolute -top-20 -right-20 h-[500px] w-[500px] rounded-full bg-primary/20 blur-[120px] pointer-events-none" />
        <div className="absolute top-40 -left-20 h-[400px] w-[400px] rounded-full bg-accent/15 blur-[120px] pointer-events-none" />

        <div className="relative mx-auto max-w-5xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-glass px-3 py-1 text-xs">
            <span className="flex h-1.5 w-1.5 rounded-full bg-accent animate-pulse" />
            <span className="text-mono uppercase tracking-widest text-muted-foreground">No SSN required</span>
          </div>

          <h1 className="text-display mt-6 text-5xl font-black leading-[0.9] sm:text-7xl md:text-[8rem]">
            Sell on TikTok.
            <br />
            <span className="bg-gradient-hero bg-clip-text text-transparent">Skip the Shop.</span>
          </h1>

          <p className="mt-8 max-w-2xl text-lg text-muted-foreground md:text-xl">
            Auto-post your Shopify products to TikTok and route every tap to a custom checkout you control.
            Built for creators TikTok Shop won't let in.
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-3">
            <Link
              to="/admin"
              className="group inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-glow-magenta hover:scale-[1.02] transition"
            >
              Connect your store
              <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition" />
            </Link>
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 rounded-full border border-border bg-glass px-6 py-3 text-sm font-semibold hover:bg-secondary transition"
            >
              See the demo storefront
            </Link>
          </div>

          <div className="mt-16 grid grid-cols-2 gap-6 sm:grid-cols-4 max-w-3xl">
            {[
              { k: "0", l: "TikTok Shop fees" },
              { k: "100%", l: "Shopify checkout" },
              { k: "<5min", l: "Setup time" },
              { k: "∞", l: "Auto-posts" },
            ].map((s) => (
              <div key={s.l} className="border-l-2 border-primary/40 pl-3">
                <div className="text-display text-3xl font-bold">{s.k}</div>
                <div className="text-xs text-muted-foreground mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="relative px-6 py-24 md:px-12">
        <div className="mx-auto max-w-5xl">
          <div className="text-mono text-xs uppercase tracking-widest text-accent mb-3">// the bridge</div>
          <h2 className="text-display text-4xl font-bold sm:text-5xl">Three moves. No middleman.</h2>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              { n: "01", t: "Shopify pushes a product", d: "Webhook fires the moment you add or update a product in your store." },
              { n: "02", t: "We post it to TikTok", d: "Auto-generated caption, your media, link back to your custom storefront." },
              { n: "03", t: "Shopify takes the money", d: "Buyers check out on infrastructure you own. PCI stays with Shopify." },
            ].map((s) => (
              <div key={s.n} className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 shadow-card hover:border-primary/50 transition">
                <div className="text-display text-7xl font-black text-primary/20 group-hover:text-primary/40 transition">{s.n}</div>
                <h3 className="mt-2 text-lg font-semibold">{s.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="relative px-6 py-24 md:px-12">
        <div className="mx-auto max-w-6xl">
          <div className="text-mono text-xs uppercase tracking-widest text-accent mb-3">// what's inside</div>
          <h2 className="text-display text-4xl font-bold sm:text-5xl max-w-2xl">Everything TikTok Shop wishes it was.</h2>

          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { i: Video, t: "Auto-post to TikTok", d: "Product webhook → caption → published video. Hands-off content engine." },
              { i: ShoppingBag, t: "Vertical product feed", d: "TikTok-style swipeable storefront on your domain. Familiar gestures, your inventory." },
              { i: Lock, t: "Custom checkout", d: "Shopify Storefront API under the hood. Your UI, Shopify's PCI compliance." },
              { i: BarChart3, t: "Click → order tracking", d: "UTM-tagged short links tie every TikTok click to a Shopify order." },
              { i: Sparkles, t: "Link in bio", d: "One link. Your products. Optimized for the TikTok in-app browser." },
              { i: Zap, t: "Inngest workflows", d: "Durable retries for posts, syncs, and webhooks. Never silently fails." },
            ].map((f) => (
              <div key={f.t} className="rounded-2xl border border-border bg-card p-6 hover:bg-surface-elevated transition">
                <f.i className="h-5 w-5 text-accent" />
                <h3 className="mt-4 font-semibold">{f.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 py-24 md:px-12">
        <div className="mx-auto max-w-4xl rounded-3xl border border-border bg-gradient-hero p-12 shadow-glow-magenta md:p-16 relative overflow-hidden">
          <div className="absolute inset-0 noise opacity-30" />
          <div className="relative">
            <h2 className="text-display text-4xl font-black text-primary-foreground sm:text-6xl">Your storefront. Their feed.</h2>
            <p className="mt-4 max-w-xl text-primary-foreground/80">
              Connect Shopify in two clicks. Start auto-posting to TikTok before your next dance trend.
            </p>
            <Link
              to="/admin"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-background px-6 py-3 text-sm font-semibold text-foreground hover:scale-[1.02] transition"
            >
              Open dashboard <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-border px-6 py-8 md:px-12">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 text-xs text-muted-foreground sm:flex-row">
          <div className="flex items-center gap-2">
            <Sparkles className="h-3.5 w-3.5" />
            <span className="text-mono">SHOPTOK · v0.1</span>
          </div>
          <span>Not affiliated with TikTok or Shopify.</span>
        </div>
      </footer>
    </div>
  );
}
