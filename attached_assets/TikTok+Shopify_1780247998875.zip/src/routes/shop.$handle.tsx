import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, ShoppingBag, Truck, RotateCcw, ShieldCheck } from "lucide-react";
import { findProduct, mockProducts } from "@/lib/mock-data";

export const Route = createFileRoute("/shop/$handle")({
  head: ({ params }) => {
    const product = findProduct(params.handle);
    return {
      meta: [
        { title: product ? `${product.title} · SHOPTOK` : "Product not found" },
        { name: "description", content: product?.description ?? "Product not found" },
        ...(product ? [{ property: "og:image", content: product.image }] : []),
      ],
    };
  },
  loader: ({ params }) => {
    const product = findProduct(params.handle);
    if (!product) throw notFound();
    return { product };
  },
  component: ProductPage,
  notFoundComponent: () => (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center">
        <h1 className="text-display text-4xl font-bold">Product not found</h1>
        <Link to="/shop" className="mt-4 inline-block text-primary hover:underline">← Back to shop</Link>
      </div>
    </div>
  ),
});

function ProductPage() {
  const data = Route.useLoaderData() as { product: NonNullable<ReturnType<typeof findProduct>> };
  const { product } = data;
  const [variantId, setVariantId] = useState(product.variants[0].id);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 border-b border-border bg-background/80 backdrop-blur">
        <Link to="/shop" className="flex items-center gap-2 text-sm">
          <ArrowLeft className="h-4 w-4" /> Back
        </Link>
        <Link to="/cart" className="rounded-full bg-secondary p-2">
          <ShoppingBag className="h-4 w-4" />
        </Link>
      </header>

      <div className="grid lg:grid-cols-2 gap-0">
        {/* Image */}
        <div className="relative aspect-square lg:aspect-auto lg:min-h-[80vh] bg-secondary overflow-hidden">
          <img src={product.image} alt={product.title} className="h-full w-full object-cover" />
        </div>

        {/* Details */}
        <div className="p-6 md:p-10 space-y-6 max-w-xl">
          <div>
            <div className="text-mono text-xs uppercase tracking-widest text-accent">{product.tags.join(" · ")}</div>
            <h1 className="text-display text-4xl md:text-5xl font-black mt-2">{product.title}</h1>
            <div className="mt-3 flex items-baseline gap-3">
              <span className="text-display text-2xl font-bold">${product.price}</span>
              {product.compareAt && (
                <span className="text-muted-foreground line-through">${product.compareAt}</span>
              )}
            </div>
          </div>

          <p className="text-muted-foreground">{product.description}</p>

          <div>
            <div className="text-xs font-semibold mb-2">Size</div>
            <div className="flex flex-wrap gap-2">
              {product.variants.map((v) => (
                <button
                  key={v.id}
                  disabled={!v.available}
                  onClick={() => setVariantId(v.id)}
                  className={`rounded-lg border px-4 py-2 text-sm transition ${
                    variantId === v.id ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-primary/50"
                  } ${!v.available ? "opacity-30 line-through cursor-not-allowed" : ""}`}
                >
                  {v.name}
                </button>
              ))}
            </div>
          </div>

          <Link
            to="/cart"
            className="block w-full text-center rounded-full bg-primary py-4 text-base font-bold text-primary-foreground shadow-glow-magenta hover:scale-[1.01] transition"
          >
            Add to cart · ${product.price}
          </Link>

          <div className="grid grid-cols-3 gap-3 pt-4 border-t border-border">
            <Trust icon={Truck} label="Free over $75" />
            <Trust icon={RotateCcw} label="30-day returns" />
            <Trust icon={ShieldCheck} label="Secure checkout" />
          </div>
        </div>
      </div>

      {/* You may also like */}
      <section className="px-6 md:px-10 py-12 border-t border-border">
        <h2 className="text-display text-2xl font-bold mb-6">More drops</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {mockProducts.filter((p) => p.handle !== product.handle).slice(0, 4).map((p) => (
            <Link
              key={p.id}
              to="/shop/$handle"
              params={{ handle: p.handle }}
              className="group"
            >
              <div className="aspect-square overflow-hidden rounded-xl bg-secondary">
                <img src={p.image} alt={p.title} className="h-full w-full object-cover group-hover:scale-105 transition" />
              </div>
              <div className="mt-2 text-sm font-medium">{p.title}</div>
              <div className="text-xs text-muted-foreground">${p.price}</div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}

function Trust({ icon: Icon, label }: { icon: React.ComponentType<{ className?: string }>; label: string }) {
  return (
    <div className="flex flex-col items-center gap-1 text-center">
      <Icon className="h-4 w-4 text-accent" />
      <span className="text-xs text-muted-foreground">{label}</span>
    </div>
  );
}
