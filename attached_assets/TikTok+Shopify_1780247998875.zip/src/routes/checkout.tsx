import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Lock, CreditCard, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "Checkout · SHOPTOK" }] }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const [step, setStep] = useState<"info" | "shipping" | "payment" | "done">("info");

  if (step === "done") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6">
        <div className="max-w-md text-center space-y-4">
          <div className="mx-auto h-16 w-16 rounded-full bg-accent flex items-center justify-center shadow-glow-lime">
            <CheckCircle2 className="h-8 w-8 text-accent-foreground" />
          </div>
          <h1 className="text-display text-4xl font-black">Order placed</h1>
          <p className="text-muted-foreground">Confirmation coming to your inbox. (demo)</p>
          <Link to="/shop" className="inline-block rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground">
            Keep shopping
          </Link>
        </div>
      </div>
    );
  }

  const steps: { id: typeof step; label: string }[] = [
    { id: "info", label: "Contact" },
    { id: "shipping", label: "Shipping" },
    { id: "payment", label: "Payment" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 border-b border-border bg-background/80 backdrop-blur">
        <Link to="/cart" className="flex items-center gap-2 text-sm">
          <ArrowLeft className="h-4 w-4" /> Back to cart
        </Link>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Lock className="h-3 w-3" /> Secure checkout
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 md:px-6 py-8 space-y-8">
        <h1 className="text-display text-4xl font-black">Checkout</h1>

        {/* Steps */}
        <div className="flex items-center gap-2">
          {steps.map((s, i) => (
            <div key={s.id} className="flex items-center gap-2 flex-1">
              <div className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold ${
                step === s.id ? "bg-primary text-primary-foreground" : steps.findIndex((x) => x.id === step) > i ? "bg-accent text-accent-foreground" : "bg-secondary text-muted-foreground"
              }`}>
                {i + 1}
              </div>
              <span className={`text-xs ${step === s.id ? "font-semibold" : "text-muted-foreground"}`}>{s.label}</span>
              {i < steps.length - 1 && <div className="flex-1 h-px bg-border" />}
            </div>
          ))}
        </div>

        {/* Forms */}
        <div className="rounded-2xl border border-border bg-card p-6 space-y-4">
          {step === "info" && (
            <>
              <Field label="Email" type="email" placeholder="you@email.com" />
              <Field label="First name" />
              <Field label="Last name" />
              <button onClick={() => setStep("shipping")} className="w-full rounded-full bg-primary py-3 font-bold text-primary-foreground shadow-glow-magenta">
                Continue to shipping
              </button>
            </>
          )}
          {step === "shipping" && (
            <>
              <Field label="Address" placeholder="123 Main St" />
              <div className="grid grid-cols-2 gap-3">
                <Field label="City" />
                <Field label="ZIP" />
              </div>
              <Field label="Country" placeholder="United States" />
              <button onClick={() => setStep("payment")} className="w-full rounded-full bg-primary py-3 font-bold text-primary-foreground shadow-glow-magenta">
                Continue to payment
              </button>
            </>
          )}
          {step === "payment" && (
            <>
              <div className="rounded-xl border border-border p-4 flex items-center gap-3">
                <CreditCard className="h-5 w-5 text-accent" />
                <div className="flex-1">
                  <div className="text-sm font-medium">Shopify Payments</div>
                  <div className="text-xs text-muted-foreground">All major cards · Apple Pay · Shop Pay</div>
                </div>
              </div>
              <Field label="Card number" placeholder="•••• •••• •••• ••••" />
              <div className="grid grid-cols-2 gap-3">
                <Field label="MM / YY" placeholder="12 / 28" />
                <Field label="CVC" placeholder="123" />
              </div>
              <button onClick={() => setStep("done")} className="w-full rounded-full bg-primary py-3 font-bold text-primary-foreground shadow-glow-magenta">
                Place order
              </button>
              <p className="text-xs text-muted-foreground text-center">PCI processing handled by Shopify. Demo only — no real charge.</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, placeholder, type = "text" }: { label: string; placeholder?: string; type?: string }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <input
        type={type}
        placeholder={placeholder}
        className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
      />
    </label>
  );
}
