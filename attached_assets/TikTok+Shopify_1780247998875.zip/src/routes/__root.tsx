import { Outlet, Link, createRootRoute, HeadContent, Scripts, useRouterState } from "@tanstack/react-router";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { Toaster } from "@/components/ui/sonner";
import { CookieConsent } from "@/components/cookie-consent";
import { TikTokPixel } from "@/components/tiktok-pixel";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-display text-8xl font-black bg-gradient-hero bg-clip-text text-transparent">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Lost in the feed</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          That page doesn't exist (or was scrolled past).
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          Back to home
        </Link>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "SHOPTOK — Sell on TikTok without TikTok Shop" },
      { name: "description", content: "Bridge your Shopify store to TikTok. Auto-post products, drive traffic, convert with your own checkout. No SSN, no Shop required." },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  // Public-facing routes: render bare (no sidebar)
  const isPublic = path === "/" || path.startsWith("/shop") || path.startsWith("/bio") || path.startsWith("/cart") || path.startsWith("/checkout") || path.startsWith("/r/");

  if (isPublic) {
    return (
      <>
        <Outlet />
        <Toaster />
        <TikTokPixel />
        <CookieConsent />
      </>
    );
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-14 flex items-center gap-3 border-b border-border px-4 bg-background/80 backdrop-blur sticky top-0 z-30">
            <SidebarTrigger />
            <span className="text-mono text-xs text-muted-foreground uppercase tracking-widest">Admin</span>
            <div className="ml-auto flex items-center gap-2">
              <Link to="/shop" className="text-xs text-muted-foreground hover:text-foreground transition">View storefront →</Link>
            </div>
          </header>
          <main className="flex-1 min-w-0">
            <Outlet />
          </main>
        </div>
      </div>
      <Toaster />
    </SidebarProvider>
  );
}
