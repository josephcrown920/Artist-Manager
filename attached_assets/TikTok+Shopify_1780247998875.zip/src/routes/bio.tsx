import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, Instagram, Music2, Globe } from "lucide-react";
import { mockProducts } from "@/lib/mock-data";

export const Route = createFileRoute("/bio")({
  head: () => ({
    meta: [
      { title: "@yourstore · Link in bio" },
      { name: "description", content: "Shop the drops you saw on TikTok." },
    ],
  }),
  component: BioPage,
});

function BioPage() {
  return (
    <div className="min-h-screen bg-gradient-hero noise text-white">
      <div className="max-w-md mx-auto px-5 py-10 space-y-6">
        {/* Profile */}
        <div className="text-center space-y-3">
          <div className="mx-auto h-24 w-24 rounded-full bg-background border-4 border-white/30 overflow-hidden shadow-card">
            <div className="h-full w-full bg-gradient-lime flex items-center justify-center">
              <Sparkles className="h-10 w-10 text-foreground" />
            </div>
          </div>
          <div>
            <h1 className="text-display text-2xl font-bold">@yourstore</h1>
            <p className="text-sm text-white/80">Streetwear for the algorithm generation</p>
          </div>
          <div className="flex items-center justify-center gap-3">
            <Social icon={Music2} />
            <Social icon={Instagram} />
            <Social icon={Globe} />
          </div>
        </div>

        {/* Featured product */}
        <Link
          to="/shop/$handle"
          params={{ handle: mockProducts[0].handle }}
          className="block relative overflow-hidden rounded-2xl bg-black/40 backdrop-blur border border-white/20"
        >
          <div className="aspect-[16/10] overflow-hidden">
            <img src={mockProducts[0].image} alt={mockProducts[0].title} className="h-full w-full object-cover" />
          </div>
          <div className="p-4">
            <div className="text-mono text-xs text-accent">⚡ JUST DROPPED</div>
            <div className="text-lg font-bold mt-1">{mockProducts[0].title}</div>
            <div className="text-sm text-white/80">${mockProducts[0].price}</div>
          </div>
        </Link>

        {/* Link list */}
        <div className="space-y-3">
          <Link
            to="/shop"
            className="block text-center rounded-2xl bg-white text-foreground py-4 font-bold hover:scale-[1.02] transition shadow-card"
          >
            🛍️  Shop the feed
          </Link>

          {mockProducts.slice(1, 5).map((p) => (
            <Link
              key={p.id}
              to="/shop/$handle"
              params={{ handle: p.handle }}
              className="flex items-center gap-3 rounded-2xl bg-black/40 backdrop-blur border border-white/20 p-3 hover:bg-black/60 transition"
            >
              <img src={p.image} alt={p.title} className="h-12 w-12 rounded-lg object-cover" />
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{p.title}</div>
                <div className="text-xs text-white/70">${p.price}</div>
              </div>
              <span className="text-white/60">→</span>
            </Link>
          ))}
        </div>

        <div className="text-center text-xs text-white/60 pt-6">
          Powered by SHOPTOK
        </div>
      </div>
    </div>
  );
}

function Social({ icon: Icon }: { icon: React.ComponentType<{ className?: string }> }) {
  return (
    <button className="h-9 w-9 rounded-full bg-white/15 backdrop-blur flex items-center justify-center hover:bg-white/25 transition">
      <Icon className="h-4 w-4" />
    </button>
  );
}
