import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plug, Store, Video, Bell, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/admin/settings")({
  head: () => ({ meta: [{ title: "Settings · SHOPTOK" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const [autoPublish, setAutoPublish] = useState(false);
  const [checkoutMode, setCheckoutMode] = useState<"shopify" | "custom">("custom");

  return (
    <div className="p-6 md:p-10 space-y-8 max-w-3xl">
      <header>
        <div className="text-mono text-xs uppercase tracking-widest text-muted-foreground">Configuration</div>
        <h1 className="text-display text-4xl font-bold mt-1">Settings</h1>
      </header>

      <Section icon={Store} title="Shopify" description="Connect your store via custom app credentials.">
        <Field label="Store domain" placeholder="your-store.myshopify.com" />
        <Field label="Admin API access token" placeholder="shpat_••••••••" type="password" />
        <Field label="Storefront API access token" placeholder="••••••••" type="password" />
      </Section>

      <Section icon={Video} title="TikTok" description="OAuth handles this — no tokens to copy.">
        <button className="rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-glow-magenta hover:opacity-90 transition">
          Connect TikTok account
        </button>
        <Toggle
          label="Auto-publish new posts"
          description="If off, posts go to the queue as drafts for review."
          enabled={autoPublish}
          onChange={setAutoPublish}
        />
      </Section>

      <Section icon={Plug} title="Checkout" description="Where buyers complete purchase.">
        <div className="grid gap-3 sm:grid-cols-2">
          <Radio
            label="Custom checkout"
            description="Built on Shopify Storefront API. Your UI."
            checked={checkoutMode === "custom"}
            onChange={() => setCheckoutMode("custom")}
          />
          <Radio
            label="Shopify-hosted"
            description="Redirect to your store's native checkout."
            checked={checkoutMode === "shopify"}
            onChange={() => setCheckoutMode("shopify")}
          />
        </div>
      </Section>

      <Section icon={Bell} title="Notifications" description="Where alerts get delivered.">
        <Field label="Email" placeholder="you@brand.com" type="email" />
      </Section>

      <Section icon={ShieldCheck} title="Privacy" description="No customer data ever leaves Shopify.">
        <p className="text-sm text-muted-foreground">
          SHOPTOK only reads product + inventory data from Shopify. All checkouts run on Shopify's PCI-compliant
          infrastructure. TikTok only ever sees public marketing posts.
        </p>
      </Section>
    </div>
  );
}

function Section({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-border bg-card p-6 space-y-4">
      <div className="flex items-center gap-3">
        <div className="h-9 w-9 rounded-lg bg-secondary flex items-center justify-center">
          <Icon className="h-4 w-4" />
        </div>
        <div>
          <h2 className="font-semibold">{title}</h2>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </div>
      <div className="space-y-3">{children}</div>
    </section>
  );
}

function Field({ label, placeholder, type = "text" }: { label: string; placeholder?: string; type?: string }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <input
        type={type}
        placeholder={placeholder}
        className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
      />
    </label>
  );
}

function Toggle({ label, description, enabled, onChange }: { label: string; description: string; enabled: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-start justify-between gap-4 pt-2">
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{description}</div>
      </div>
      <button
        onClick={() => onChange(!enabled)}
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${enabled ? "bg-primary" : "bg-secondary"}`}
        aria-pressed={enabled}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-foreground transition ${enabled ? "left-[22px]" : "left-0.5"}`} />
      </button>
    </div>
  );
}

function Radio({ label, description, checked, onChange }: { label: string; description: string; checked: boolean; onChange: () => void }) {
  return (
    <button
      onClick={onChange}
      className={`text-left rounded-xl border p-4 transition ${
        checked ? "border-primary bg-primary/5 shadow-glow-magenta" : "border-border hover:border-primary/40"
      }`}
    >
      <div className="flex items-start gap-2">
        <div className={`mt-1 h-3.5 w-3.5 rounded-full border-2 ${checked ? "border-primary bg-primary" : "border-muted-foreground"}`} />
        <div>
          <div className="text-sm font-medium">{label}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{description}</div>
        </div>
      </div>
    </button>
  );
}
