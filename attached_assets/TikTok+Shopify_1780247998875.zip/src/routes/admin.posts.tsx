import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { mockPosts, type MockTikTokPost } from "@/lib/mock-data";
import { Calendar, Send, Edit3, Trash2, Sparkles, AlertCircle, CheckCircle2, Clock, FileText } from "lucide-react";

export const Route = createFileRoute("/admin/posts")({
  head: () => ({ meta: [{ title: "Posts · SHOPTOK" }] }),
  component: PostsPage,
});

const tabs = [
  { id: "all", label: "All" },
  { id: "draft", label: "Drafts" },
  { id: "scheduled", label: "Scheduled" },
  { id: "published", label: "Published" },
  { id: "failed", label: "Failed" },
] as const;

function PostsPage() {
  const [tab, setTab] = useState<(typeof tabs)[number]["id"]>("all");
  const filtered = tab === "all" ? mockPosts : mockPosts.filter((p) => p.status === tab);

  return (
    <div className="p-6 md:p-10 space-y-6 max-w-7xl">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-mono text-xs uppercase tracking-widest text-muted-foreground">Content engine</div>
          <h1 className="text-display text-4xl font-bold mt-1">TikTok post queue</h1>
          <p className="text-muted-foreground mt-2 text-sm">Auto-generated from your Shopify product webhooks.</p>
        </div>
        <button className="inline-flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground shadow-glow-lime hover:scale-[1.02] transition">
          <Sparkles className="h-4 w-4" /> Generate from product
        </button>
      </header>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-border pb-px">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative rounded-t-lg px-4 py-2 text-sm font-medium transition ${
              tab === t.id ? "bg-card text-foreground" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
            {tab === t.id && <span className="absolute inset-x-0 -bottom-px h-0.5 bg-primary" />}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full rounded-2xl border border-dashed border-border p-12 text-center text-sm text-muted-foreground">
            Nothing here yet.
          </div>
        )}
      </div>
    </div>
  );
}

function PostCard({ post }: { post: MockTikTokPost }) {
  const statusMeta = {
    draft: { icon: FileText, color: "text-muted-foreground", bg: "bg-secondary", label: "Draft" },
    scheduled: { icon: Clock, color: "text-cyan", bg: "bg-cyan/10", label: "Scheduled" },
    published: { icon: CheckCircle2, color: "text-accent", bg: "bg-accent/10", label: "Published" },
    failed: { icon: AlertCircle, color: "text-destructive", bg: "bg-destructive/10", label: "Failed" },
  }[post.status];

  const Icon = statusMeta.icon;

  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card hover:border-primary/40 transition">
      {/* Vertical thumbnail (TikTok aspect) */}
      <div className="relative aspect-[9/16] overflow-hidden bg-secondary">
        <img src={post.thumbnail} alt={post.productTitle} className="h-full w-full object-cover" />
        <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-black/80 to-transparent" />
        <div className={`absolute top-3 left-3 inline-flex items-center gap-1 rounded-full ${statusMeta.bg} px-2 py-1 text-[10px] font-medium ${statusMeta.color}`}>
          <Icon className="h-3 w-3" /> {statusMeta.label}
        </div>
        {post.status === "published" && post.views && (
          <div className="absolute bottom-3 left-3 text-mono text-xs text-white">
            <div>{post.views.toLocaleString()} views</div>
            <div className="text-accent">{post.clicks?.toLocaleString()} clicks</div>
          </div>
        )}
      </div>

      <div className="p-4 space-y-3">
        <div className="text-xs text-muted-foreground">{post.productTitle}</div>
        <p className="text-sm line-clamp-3">{post.caption}</p>
        {post.scheduledFor && (
          <div className="flex items-center gap-1 text-xs text-cyan">
            <Calendar className="h-3 w-3" /> {new Date(post.scheduledFor).toLocaleString()}
          </div>
        )}
        <div className="flex items-center gap-1 pt-2 border-t border-border">
          {post.status !== "published" && (
            <button className="flex-1 inline-flex items-center justify-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground hover:opacity-90 transition">
              <Send className="h-3 w-3" /> Publish
            </button>
          )}
          <button className="rounded-lg border border-border px-2 py-1.5 hover:bg-secondary transition" aria-label="Edit">
            <Edit3 className="h-3.5 w-3.5" />
          </button>
          <button className="rounded-lg border border-border px-2 py-1.5 hover:bg-destructive/20 hover:text-destructive transition" aria-label="Delete">
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
