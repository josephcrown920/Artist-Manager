import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Minus, Plus, X, ShoppingBag } from "lucide-react";
import { mockProducts } from "@/lib/mock-data";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Cart · SHOPTOK" }] }),
  component: CartPage,
});

type CartItem = { handle: string; qty: number; size: string };

function CartPage() {
  const [items, setItems] = useState<CartItem[]>([
    { handle: "neon-cargo-pants", qty: 1, size: "M" },
    { handle: "chrome-bucket-hat", qty: 2, size: "One Size" },
  ]);

  const lines = items
    .map((it) => {
      const p = mockProducts.find((x) => x.handle === it.handle);
      return p ? { ...it, product: p } : null;
    })
    .filter((x): x is NonNullable<typeof x> => !!x);

  const subtotal = lines.reduce((sum, l) => sum + l.product.price * l.qty, 0);
  const shipping = subtotal > 75 ? 0 : 8;
  const total = subtotal + shipping;

  const update = (handle: string, qty: number) => {
    if (qty <= 0) setItems((arr) => arr.filter((x) => x.handle !== handle));
    else setItems((arr) => arr.map((x) => (x.handle === handle ? { ...x, qty } : x)));
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 border-b border-border bg-background/80 backdrop-blur">
        <Link to="/shop" className="flex items-center gap-2 text-sm">
          <ArrowLeft className="h-4 w-4" /> Continue shopping
        </Link>
        <span className="text-mono text-xs text-muted-foreground">{lines.length} items</span>
      </header>

      <div className="max-w-3xl mx-auto px-4 md:px-6 py-8 space-y-6">
        <h1 className="text-display text-4xl font-black">Cart</h1>

        {lines.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border p-12 text-center">
            <ShoppingBag className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="mt-3 text-muted-foreground">Your cart is empty.</p>
            <Link to="/shop" className="mt-4 inline-block rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground">
              Shop the feed
            </Link>
          </div>
        ) : (
          <>
            <div className="space-y-3">
              {lines.map((line) => (
                <div key={line.handle} className="flex gap-4 rounded-2xl border border-border bg-card p-4">
                  <img src={line.product.image} alt={line.product.title} className="h-24 w-24 rounded-lg object-cover" />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-semibold">{line.product.title}</div>
                        <div className="text-xs text-muted-foreground">Size {line.size}</div>
                      </div>
                      <button onClick={() => update(line.handle, 0)} className="text-muted-foreground hover:text-destructive">
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="mt-3 flex items-center justify-between">
                      <div className="flex items-center gap-1 rounded-full border border-border">
                        <button onClick={() => update(line.handle, line.qty - 1)} className="px-2 py-1 hover:bg-secondary rounded-l-full">
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="px-3 text-sm font-medium">{line.qty}</span>
                        <button onClick={() => update(line.handle, line.qty + 1)} className="px-2 py-1 hover:bg-secondary rounded-r-full">
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <div className="text-display font-bold">${line.product.price * line.qty}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl border border-border bg-card p-6 space-y-3">
              <Row label="Subtotal" value={`$${subtotal}`} />
              <Row label="Shipping" value={shipping === 0 ? "Free" : `$${shipping}`} />
              <div className="border-t border-border pt-3">
                <Row label="Total" value={`$${total}`} bold />
              </div>
              <Link
                to="/checkout"
                className="mt-4 block w-full text-center rounded-full bg-primary py-4 font-bold text-primary-foreground shadow-glow-magenta hover:scale-[1.01] transition"
              >
                Checkout
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, bold = false }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex justify-between text-sm">
      <span className={bold ? "font-semibold" : "text-muted-foreground"}>{label}</span>
      <span className={bold ? "text-display text-lg font-bold" : "font-medium"}>{value}</span>
    </div>
  );
}
