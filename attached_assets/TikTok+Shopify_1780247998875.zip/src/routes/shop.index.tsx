import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Heart, ShoppingBag, Share2, Music2, ChevronUp, ChevronDown } from "lucide-react";
import { mockProducts } from "@/lib/mock-data";

export const Route = createFileRoute("/shop/")({
  head: () => ({
    meta: [
      { title: "Shop · SHOPTOK" },
      { name: "description", content: "Swipe-to-shop. Vertical product feed for the algorithm generation." },
    ],
  }),
  component: ShopFeed,
});

function ShopFeed() {
  const [index, setIndex] = useState(0);
  const product = mockProducts[index];

  const next = () => setIndex((i) => (i + 1) % mockProducts.length);
  const prev = () => setIndex((i) => (i - 1 + mockProducts.length) % mockProducts.length);

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* Header */}
      <header className="absolute top-0 inset-x-0 z-30 flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/70 to-transparent">
        <Link to="/" className="text-display text-sm font-bold">SHOPTOK</Link>
        <Link to="/cart" className="rounded-full bg-white/10 backdrop-blur p-2">
          <ShoppingBag className="h-4 w-4" />
        </Link>
      </header>

      {/* Feed item */}
      <div className="relative h-screen w-full max-w-md mx-auto">
        <img src={product.image} alt={product.title} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/40" />

        {/* Right rail actions */}
        <div className="absolute right-3 bottom-32 flex flex-col items-center gap-5 z-20">
          <ActionButton icon={Heart} label="12.4k" />
          <ActionButton icon={Share2} label="Share" />
          <button onClick={prev} className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 backdrop-blur" aria-label="Previous">
            <ChevronUp className="h-5 w-5" />
          </button>
          <button onClick={next} className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 backdrop-blur" aria-label="Next">
            <ChevronDown className="h-5 w-5" />
          </button>
        </div>

        {/* Bottom info */}
        <div className="absolute inset-x-0 bottom-0 z-20 p-5 pb-8 space-y-3">
          <div className="text-mono text-xs text-accent">@yourstore</div>
          <h1 className="text-display text-3xl font-bold">{product.title}</h1>
          <p className="text-sm text-white/80 line-clamp-2">{product.description}</p>
          <div className="flex items-center gap-1.5 text-xs text-white/70">
            <Music2 className="h-3 w-3" /> original sound · {product.title.toLowerCase()}
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Link
              to="/shop/$handle"
              params={{ handle: product.handle }}
              className="flex-1 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-bold text-primary-foreground shadow-glow-magenta"
            >
              <ShoppingBag className="h-4 w-4" /> Shop · ${product.price}
            </Link>
            {product.compareAt && (
              <span className="text-sm line-through text-white/50">${product.compareAt}</span>
            )}
          </div>
        </div>

        {/* Progress dots */}
        <div className="absolute right-3 top-16 z-20 flex flex-col gap-1">
          {mockProducts.map((_, i) => (
            <div
              key={i}
              className={`h-6 w-0.5 rounded-full transition ${i === index ? "bg-primary" : "bg-white/30"}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function ActionButton({ icon: Icon, label }: { icon: React.ComponentType<{ className?: string }>; label: string }) {
  return (
    <button className="flex flex-col items-center gap-1">
      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white/10 backdrop-blur">
        <Icon className="h-5 w-5" />
      </div>
      <span className="text-xs">{label}</span>
    </button>
  );
}
