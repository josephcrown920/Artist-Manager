export type MockProduct = {
  id: string;
  handle: string;
  title: string;
  price: number;
  compareAt?: number;
  image: string;
  video?: string;
  description: string;
  inventory: number;
  variants: { id: string; name: string; available: boolean }[];
  tags: string[];
};

export const mockProducts: MockProduct[] = [
  {
    id: "p1",
    handle: "neon-cargo-pants",
    title: "Neon Cargo Pants",
    price: 89,
    compareAt: 120,
    image: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=900&q=80",
    description: "Oversized cargo silhouette with reflective trim. Built for the feed.",
    inventory: 42,
    variants: [
      { id: "s", name: "S", available: true },
      { id: "m", name: "M", available: true },
      { id: "l", name: "L", available: false },
      { id: "xl", name: "XL", available: true },
    ],
    tags: ["streetwear", "trending"],
  },
  {
    id: "p2",
    handle: "chrome-bucket-hat",
    title: "Chrome Bucket Hat",
    price: 38,
    image: "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?w=900&q=80",
    description: "Liquid-metal finish. One size, infinite vibes.",
    inventory: 128,
    variants: [{ id: "os", name: "One Size", available: true }],
    tags: ["accessories", "viral"],
  },
  {
    id: "p3",
    handle: "acid-wash-tee",
    title: "Acid Wash Tee",
    price: 42,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=900&q=80",
    description: "Heavyweight cotton, hand-distressed. No two are the same.",
    inventory: 67,
    variants: [
      { id: "s", name: "S", available: true },
      { id: "m", name: "M", available: true },
      { id: "l", name: "L", available: true },
    ],
    tags: ["basics"],
  },
  {
    id: "p4",
    handle: "holo-crossbody",
    title: "Holo Crossbody",
    price: 64,
    compareAt: 80,
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=900&q=80",
    description: "Iridescent shell, magnetic close, hands-free for the dance.",
    inventory: 23,
    variants: [{ id: "os", name: "One Size", available: true }],
    tags: ["accessories", "trending"],
  },
  {
    id: "p5",
    handle: "platform-runner",
    title: "Platform Runner",
    price: 145,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900&q=80",
    description: "50mm platform, cloud foam midsole. Cameras eat it up.",
    inventory: 18,
    variants: [
      { id: "8", name: "8", available: true },
      { id: "9", name: "9", available: true },
      { id: "10", name: "10", available: false },
      { id: "11", name: "11", available: true },
    ],
    tags: ["footwear", "viral"],
  },
  {
    id: "p6",
    handle: "matrix-shades",
    title: "Matrix Shades",
    price: 28,
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=900&q=80",
    description: "Wraparound UV400. Main character energy.",
    inventory: 211,
    variants: [{ id: "os", name: "One Size", available: true }],
    tags: ["accessories"],
  },
];

export type MockTikTokPost = {
  id: string;
  productHandle: string;
  productTitle: string;
  thumbnail: string;
  caption: string;
  status: "draft" | "scheduled" | "published" | "failed";
  scheduledFor?: string;
  views?: number;
  clicks?: number;
};

export const mockPosts: MockTikTokPost[] = [
  {
    id: "tp1",
    productHandle: "neon-cargo-pants",
    productTitle: "Neon Cargo Pants",
    thumbnail: "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=400&q=80",
    caption: "POV: cargo szn just hit different 🔥 link in bio #streetwear #fyp",
    status: "published",
    views: 142800,
    clicks: 3210,
  },
  {
    id: "tp2",
    productHandle: "chrome-bucket-hat",
    productTitle: "Chrome Bucket Hat",
    thumbnail: "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?w=400&q=80",
    caption: "the bucket hat that broke the algorithm 🪩 grab yours, link in bio",
    status: "scheduled",
    scheduledFor: "2026-04-29T18:00:00Z",
  },
  {
    id: "tp3",
    productHandle: "platform-runner",
    productTitle: "Platform Runner",
    thumbnail: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80",
    caption: "+2 inches of confidence 👟 we restocked, run don't walk",
    status: "draft",
  },
  {
    id: "tp4",
    productHandle: "holo-crossbody",
    productTitle: "Holo Crossbody",
    thumbnail: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400&q=80",
    caption: "iridescent obsession era 💿 limited drop, link in bio",
    status: "published",
    views: 89400,
    clicks: 1980,
  },
  {
    id: "tp5",
    productHandle: "acid-wash-tee",
    productTitle: "Acid Wash Tee",
    thumbnail: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&q=80",
    caption: "the only tee in your rotation that matters this summer 🧪",
    status: "failed",
  },
];

export const mockAnalytics = {
  totals: {
    tiktokClicks: 18420,
    sessions: 14210,
    orders: 312,
    revenue: 24180,
    conversionRate: 2.2,
  },
  daily: [
    { date: "Mon", clicks: 1820, orders: 28 },
    { date: "Tue", clicks: 2140, orders: 41 },
    { date: "Wed", clicks: 2890, orders: 52 },
    { date: "Thu", clicks: 2410, orders: 38 },
    { date: "Fri", clicks: 3120, orders: 61 },
    { date: "Sat", clicks: 3580, orders: 58 },
    { date: "Sun", clicks: 2460, orders: 34 },
  ],
  topProducts: [
    { handle: "neon-cargo-pants", title: "Neon Cargo Pants", clicks: 4210, orders: 89 },
    { handle: "platform-runner", title: "Platform Runner", clicks: 3890, orders: 71 },
    { handle: "holo-crossbody", title: "Holo Crossbody", clicks: 2980, orders: 54 },
    { handle: "chrome-bucket-hat", title: "Chrome Bucket Hat", clicks: 2410, orders: 48 },
  ],
};

export function findProduct(handle: string): MockProduct | undefined {
  return mockProducts.find((p) => p.handle === handle);
}
