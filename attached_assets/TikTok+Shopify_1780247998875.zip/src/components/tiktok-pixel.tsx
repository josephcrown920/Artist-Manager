import { useEffect } from "react";
import { getConsent } from "./cookie-consent";

const PIXEL_ID = import.meta.env.VITE_TIKTOK_PIXEL_ID as string | undefined;

declare global {
  interface Window {
    ttq?: any;
    __ttqLoaded?: boolean;
  }
}

function loadPixel(pixelId: string) {
  if (typeof window === "undefined" || window.__ttqLoaded) return;
  window.__ttqLoaded = true;
  /* eslint-disable */
  (function (w: any, d: any, t: any) {
    w.TiktokAnalyticsObject = t;
    var ttq = (w[t] = w[t] || []);
    ttq.methods = ["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"];
    ttq.setAndDefer = function (t: any, e: any) { t[e] = function () { t.push([e].concat(Array.prototype.slice.call(arguments, 0))); }; };
    for (var i = 0; i < ttq.methods.length; i++) ttq.setAndDefer(ttq, ttq.methods[i]);
    ttq.instance = function (t: any) {
      for (var e = ttq._i[t] || [], n = 0; n < ttq.methods.length; n++) ttq.setAndDefer(e, ttq.methods[n]);
      return e;
    };
    ttq.load = function (e: any, n: any) {
      var r = "https://analytics.tiktok.com/i18n/pixel/events.js";
      ttq._i = ttq._i || {}; ttq._i[e] = []; ttq._i[e]._u = r;
      ttq._t = ttq._t || {}; ttq._t[e] = +new Date();
      ttq._o = ttq._o || {}; ttq._o[e] = n || {};
      var o = d.createElement("script");
      o.type = "text/javascript"; o.async = true; o.src = r + "?sdkid=" + e + "&lib=" + t;
      var a = d.getElementsByTagName("script")[0];
      a.parentNode.insertBefore(o, a);
    };
    ttq.load(pixelId);
    ttq.page();
  })(window, document, "ttq");
  /* eslint-enable */
}

export function TikTokPixel() {
  useEffect(() => {
    if (!PIXEL_ID) return;
    if (getConsent() === "accepted") loadPixel(PIXEL_ID);
    const onConsent = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail === "accepted") loadPixel(PIXEL_ID);
    };
    window.addEventListener("shoptok-consent", onConsent);
    return () => window.removeEventListener("shoptok-consent", onConsent);
  }, []);
  return null;
}
