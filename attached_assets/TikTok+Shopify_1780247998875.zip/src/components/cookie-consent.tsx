import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

const STORAGE_KEY = "shoptok-consent-v1";

export type ConsentValue = "accepted" | "rejected";

export function getConsent(): ConsentValue | null {
  if (typeof window === "undefined") return null;
  const v = window.localStorage.getItem(STORAGE_KEY);
  return v === "accepted" || v === "rejected" ? v : null;
}

export function CookieConsent() {
  const [choice, setChoice] = useState<ConsentValue | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    setChoice(getConsent());
  }, []);

  const decide = (v: ConsentValue) => {
    window.localStorage.setItem(STORAGE_KEY, v);
    setChoice(v);
    window.dispatchEvent(new CustomEvent("shoptok-consent", { detail: v }));
  };

  if (!mounted || choice) return null;

  return (
    <div
      role="dialog"
      aria-label="Cookie consent"
      className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-2xl rounded-xl border border-border bg-card/95 backdrop-blur p-4 shadow-2xl md:flex md:items-center md:gap-4"
    >
      <p className="text-sm text-foreground flex-1">
        We use cookies and the TikTok Pixel to measure traffic and improve your experience.{" "}
        <a href="/privacy" className="underline underline-offset-2 hover:text-primary">Learn more</a>.
      </p>
      <div className="mt-3 flex gap-2 md:mt-0 md:shrink-0">
        <Button variant="outline" size="sm" onClick={() => decide("rejected")}>
          Reject
        </Button>
        <Button size="sm" onClick={() => decide("accepted")}>
          Accept all
        </Button>
      </div>
    </div>
  );
}
